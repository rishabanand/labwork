package com.cg.lims.dao;

import java.util.ArrayList;

import com.cg.lims.Exception.RegistrationException;
import com.cg.lims.bean.BooksInventory;
import com.cg.lims.bean.BooksRegistration;

public interface RegistrationDao
{
	public int addRegistrationDetails(BooksRegistration register)throws RegistrationException,Exception;
	public String generateRegistId() throws RegistrationException,Exception;
	public ArrayList<String> getBookId() throws RegistrationException;
	public ArrayList<String> getUserId() throws RegistrationException;
	public int addBookInventory(BooksInventory bookInv) throws RegistrationException;
	public String generateBookId() throws RegistrationException,Exception;
	public int deleteBook(String bId) throws RegistrationException,Exception;
}

package com.cg.lims.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import com.cg.lims.Exception.BooksTransactionException;
import com.cg.lims.Exception.RegistrationException;
import com.cg.lims.bean.BookTransaction;
import com.cg.lims.util.DBUtil;

public class BooksTransactionDaoImpl implements BooksTransactionDao
{
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;

	@Override
	public String generateTransactionId() throws BooksTransactionException 
	{

		String qry="SELECT 'BT'||to_char(book_tran_id_seq.NEXTVAL,'FM00') FROM DUAL";
		String generatedVal=null;
		try
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(qry);
			rs.next();
			generatedVal=rs.getString(1);
		}
		catch (Exception e)
		{			
			throw new BooksTransactionException("Problem in generating the Id"+e.getMessage());
		}
		finally
		{
			try 
			{
				rs.close();
				st.close();
				con.close();
			} 
			catch (Exception e)
			{
				throw new BooksTransactionException(e.getMessage());
			}
		}
		return  generatedVal;
	}

	@Override
	public ArrayList<String> getRegId() throws RegistrationException 
	{		
		ArrayList<String> RegIds=new ArrayList<String>();
		String selectQry=" SELECT registration_id FROM booksregistration";

		try
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(selectQry);
			while(rs.next())
			{
				String RegId=rs.getString("registration_id");
				RegIds.add(RegId);
			}
		}
		catch (Exception e)
		{
			throw new RegistrationException("Problem in getting the registration Id list "+e.getMessage());
		} 
		finally
		{
			try
			{
				rs.close();
				st.close();
				con.close();
			}
			catch (Exception e)
			{
				throw new RegistrationException(e.getMessage());
			}
		}
		return RegIds;
	}


	@Override
	public int issueBook(BookTransaction bookTransaction)
			throws BooksTransactionException 
	{
		String insertQry="INSERT INTO BooksTransaction VALUES(?,?,sysdate,sysdate+14,0)";
		int dataAdded=0;
		try
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(insertQry);
			pst.setString(1, bookTransaction.getTransactionId());		
			pst.setString (2, bookTransaction.getRegistrationId());
			dataAdded=pst.executeUpdate();
		}
		catch (Exception e)
		{
			throw new BooksTransactionException("Problem in inserting data in bookTransaction "+e.getMessage());
		}
		finally
		{
			try
			{
				pst.close();
				con.close();
			}
			catch (Exception e)
			{     

				throw new BooksTransactionException(e.getMessage());
			}
		}
		return dataAdded;
	}

	@Override
	public Date getReturnDate(String registrationId) throws BooksTransactionException
	{
		String qry="SELECT return_date from Bookstransaction WHERE registration_id =?";
		Date returnDate = null;
		try
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(qry);
			pst.setString(1,registrationId);
			rs=pst.executeQuery();
			rs.next();
			returnDate=rs.getDate("return_date");

		}
		catch (Exception e)
		{
			throw new BooksTransactionException("Problem in getting the return date "+e.getMessage());
		}
		return returnDate;
	}

	@Override
	public int updateReturnDateAndFine(String registrationId,int fine)
			throws BooksTransactionException 
	{
		String updateQry="UPDATE BOOKSTRANSACTION SET return_date=sysdate,fine=? WHERE registration_id =?";
		int dataUpdated=0;
		try
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(updateQry);
			pst.setInt(1,fine);
			pst.setString(2,registrationId);
			dataUpdated=pst.executeUpdate();		
		} 
		catch (Exception e) 
		{			
			throw new BooksTransactionException("Problem in updating the BookTransaction "+e.getMessage());
		}
		finally
		{
			try 
			{
				pst.close();
				con.close();
			} 
			catch (Exception e)
			{				
				throw new BooksTransactionException(e.getMessage());
			}
		}

		return dataUpdated;

	}

	@Override
	public String getBookIdByRegistrationId(String registrationId)
			throws BooksTransactionException 
	{
		String bookId=null;
		String qry="SELECT book_id from BooksRegistration where registration_id =?";
		try
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(qry);
			pst.setString(1,registrationId);
			rs=pst.executeQuery();
			rs.next();
			bookId=rs.getString("book_id");
		}
		catch (Exception e)
		{
			throw new BooksTransactionException("Problem in getting the BookId "+e.getMessage());
		}
		return bookId;
	}

}

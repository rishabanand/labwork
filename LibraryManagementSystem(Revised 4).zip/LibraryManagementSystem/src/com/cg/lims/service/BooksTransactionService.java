package com.cg.lims.service;

import java.sql.Date;
import java.util.ArrayList;

import com.cg.lims.Exception.BooksTransactionException;
import com.cg.lims.Exception.RegistrationException;
import com.cg.lims.bean.BookTransaction;

public interface BooksTransactionService
{
	public String generateTransactionId() throws BooksTransactionException;
	public ArrayList<String> getRegId() throws RegistrationException;
	public int issueBook(BookTransaction bookTransaction) throws BooksTransactionException;
	
	public boolean validateRegId(String RegId) throws RegistrationException;
	public int calculateFine(String transactionId) throws BooksTransactionException;
	
	
	public Date getReturnDate(String transactionId) throws BooksTransactionException;
	public int updateReturnDateAndFine(String transactionId,int fine)throws BooksTransactionException;
	public String getBookIdByRegistrationId(String registrationId)throws BooksTransactionException;
}

package com.cg.lims.service;

import java.util.ArrayList;

import com.cg.lims.Exception.RegistrationException;
import com.cg.lims.bean.BooksRegistration;
import com.cg.lims.dao.RegistrationDao;
import com.cg.lims.dao.RegistrationDaoImpl;

public class RegistrationServiceImpl implements RegistrationService
{
	RegistrationDao regDao=null;
	public RegistrationServiceImpl()
	{
		regDao=new RegistrationDaoImpl();
	}

	@Override
	public int addRegistrationDetails(BooksRegistration register)
			throws RegistrationException, Exception 
	{		
		return regDao.addRegistrationDetails(register);
	}

	@Override
	public boolean validateIds(String userId,String BookId) throws RegistrationException 
	{		
		if(validateBookId(BookId) && validateUserId(userId))
		{
			return true;
		}		
		return false;
	}
	private boolean validateUserId(String userId) throws RegistrationException
	{
		ArrayList<String> userIds=regDao.getUserId();
		for(String tempuserIds :userIds)
		{
			if(userId.equals(tempuserIds))
			{
				return true;
			}
		}
		return false;			
	}
	private boolean validateBookId(String bookId) throws RegistrationException
	{
		ArrayList<String> bookIds=regDao.getBookId();
		for(String tempbookIds :bookIds)
		{			
			if(bookId.equals(tempbookIds))
			{
				return true;
			}
		}
		return false;		
	}

	@Override
	public String generateRegistId() throws RegistrationException, Exception
	{		
		return regDao.generateRegistId();
	}
}

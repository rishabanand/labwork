import java.util.regex.*;
public class TestPersonInfo
{
	public static void main(String[] args)
	{
		Person1 p1 = new Person1("d ","b ",'F');
		String firstNamePattern="[A-Z][A-Za-z]{4,}";
		String lastNamePattern="[A-Z][A-Za-z]{3,}";
		if(p1.getFirstName().compareTo(" ")==0 || p1.getLastName().compareTo(" ")==0)
		{
			try 
			{
				throw new FullNameException("Please Enter the Name");
			} 
			catch (FullNameException e)
			{				
				System.out.println("You cannot leave this field empty");
			}
		}
		else if(Pattern.matches(firstNamePattern, p1.getFirstName()))
		{
			System.out.println("Valid First Name");
		}
		else if(Pattern.matches(lastNamePattern, p1.getLastName()))
		{
			System.out.println("Valid Last Name");
		}
		else
		{
			System.out.println("First Letter should be capital and Minimum four characters are allowed in first name and last name");
		}
	}
}

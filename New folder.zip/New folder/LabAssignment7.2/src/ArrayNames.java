import java.util.*;
public class ArrayNames 
{
	public static void main(String[] args) 
	{
		
		ArrayList<String> listOfNames = new ArrayList<String>();
		listOfNames.add("Rishab");
		listOfNames.add("Divya");
		listOfNames.add("Shushant");
		listOfNames.add("Raju");
		listOfNames.add("Priyanka");
		
		System.out.println("Before Sorting:");
		System.out.println("***************");
		   for(String counter: listOfNames)
		   {
				System.out.println(counter);
		   }
		   Collections.sort(listOfNames);
		   System.out.println(" ");
		   System.out.println("After Sorting:");
		   System.out.println("***************");
		   for(String counter: listOfNames)
		   {
				System.out.println(counter);
		   }
	}
}

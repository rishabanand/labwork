package com.cg.eis.pl;
import com.cg.eis.bean.*;
import com.cg.eis.service.*;
import com.cg.eis.exception.*;

import java.util.*;
public class TestEmployeeInfo 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Employee Id :");
		int empId=sc.nextInt();
		System.out.println("Enter the Employee Name :");
		String enm=sc.next();
		System.out.println("Enter the employee Salary :");
		double esl=sc.nextDouble();
		System.out.println("Enter the designation :");
		String eDes=sc.next();
		Service s=new Service();
		Employee e=new Employee(empId,enm,esl,eDes,s);
		System.out.println(e);
		
		if(esl<3000)
		{
			try
			{
				throw new EmployeeException("Not valid Salary");
			} 
			catch (EmployeeException e1) 
			{				
				System.out.println("Salary Must be above 3000");
			}
		}
		else
		{
			System.out.println("Valid Salary");
		}
		
	}
}

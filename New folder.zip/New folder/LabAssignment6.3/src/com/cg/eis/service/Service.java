package com.cg.eis.service;

public class Service implements EmployeeInterface
{
	
	public String calInsuranceScheme(double salary,String designation)
	{
		String insScheme=null;
		if(salary>5000 && salary<20000  && designation.compareTo("SystemAssociate")==0)
		{
			 insScheme="SchemeC";
		}
		else if(salary>=20000 && salary<40000 && designation.compareTo("Programmer")==0)
		{
			 insScheme="SchemeB";
		}
		else if(salary>=40000 && designation.compareTo("Manager")==0)
		{
			 insScheme="SchemeA";
		}
		else if(salary<5000  && designation.compareTo("Clerk")==0)
		{
			 insScheme="No Scheme";
		}
		
		return insScheme;
	}
}

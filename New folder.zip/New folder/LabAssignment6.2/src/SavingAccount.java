
public class SavingAccount extends Account
{
	private final double minBalance =500;
	
 
 	public SavingAccount() 
 	{
 		super();
 	}


 	public SavingAccount(long accNum, double balance, Person accHolder)
 	{
 		super(accNum, balance, accHolder);
	}


@Override
 public void withdrawal(double withdrawalAmt)
	{
		 if((getBalance()-withdrawalAmt)>minBalance)
		 {
			super.withdrawal(withdrawalAmt); 
		 }
		 else
			 System.out.println("Insufficient amount ");
	}
 
}


public class CurrentAccount extends Account
{
	private final double overDraftLimit=40000 ;

	public CurrentAccount()
	{
		super();
	}

	public CurrentAccount(long accNum, double balance, Person accHolder) 
	{
		super(accNum, balance, accHolder);
	}
	@Override
	 public void withdrawal(double withdrawalAmt)
		{
			 if(withdrawalAmt<overDraftLimit)
			 {
				super.withdrawal(withdrawalAmt); 
			 }
			 else
				 System.out.println(" Over Draft Limit reached ");
		}
}

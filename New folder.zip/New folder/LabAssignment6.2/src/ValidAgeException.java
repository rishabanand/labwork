
public class ValidAgeException extends Exception
{
	public ValidAgeException(String msg)
	{
		super(msg);
	}
}

package com.cg.eis.pl;
import com.cg.eis.bean.*;
import com.cg.eis.service.*;
import java.util.*;
public class TestEmployeeInfo 
{
	
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Employee Id :");
		int empId=sc.nextInt();
		System.out.println("Enter the Employee Name :");
		String enm=sc.next();
		System.out.println("Enter the employee Salary :");
		double esl=sc.nextDouble();
		System.out.println("Enter the designation :");
		String eDes=sc.next();
		System.out.println("Enter the Insurance scheme");
		String insSch=sc.next();
		System.out.println("Choose The Option\n1.Add An Employee"
				+ "\n2.Display Employee Details based on Insurance Scheme"
				+ "\n3.Delete an Employee"
				+ "\n5.Sort The Employee details based on Salary");
		System.out.println("Enter the choice :");
		int choice=sc.nextInt();
		
		Service s=new Service();
		Employee e=new Employee(empId,enm,esl,eDes,insSch);
		s.addEmployee(e);
		switch(choice)
		{
		case 1:
			s.addEmployee(e);
			break;
		case 2:
			s.getEmpByInsu(insSch);
			break;
		case 3:
			boolean res= s.deleteEmployeeById(empId);
			System.out.println("Record Deleted"+res);
		}
		
	}
}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.net.ConnectException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Date;
/**
 *
 * @author DELL
 */
public class FeedBack extends HttpServlet {

    Connection c1;
    PreparedStatement pst;
    ResultSet rs;
   
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {
           String fn=request.getParameter("t1");
           String ln=request.getParameter("t2");
           String em=request.getParameter("t3");
           String fd=request.getParameter("t4");
           String btn=request.getParameter("bt1");
           Date dt=new Date();
           String dtt=dt.toLocaleString();
           Class.forName("com.mysql.jdbc.Driver").newInstance();
           c1=DriverManager.getConnection("jdbc:mysql://localhost/FeedBack","root","admin");
           pst=c1.prepareStatement("insert into Feedbk(First_Name,Last_Name,Email,Feedback,Feeddate) values(?,?,?,?,?)");
           pst.setString(1,fn);
           pst.setString(2,ln);
           pst.setString(3,em);
           pst.setString(4,fd);
           pst.setString(5,dtt);
          int j=pst.executeUpdate();
          if(j>0)
          {
              out.println("<script>alert('FeedBack Submitted')</script>");
          }
          else
          {
         out.println("<script>alert('FeedBack Not Submitted')</script>");
          }
          }
           
           catch(Exception e)
           {
           out.println("Error is"+e);
        }
        finally {            
            out.close();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP
     * <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP
     * <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}

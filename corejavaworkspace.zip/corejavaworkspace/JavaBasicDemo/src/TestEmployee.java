
public class TestEmployee
{

	public static void main(String[] args)
	{
		Employee rishab = new Employee(101,"Rishab",20000,'M');
		rishab.displayEmployee();
	}
}

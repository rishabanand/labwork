
public class Student
{
	private int rollNo;
	private String stuName;
	private int marks;
	
	public Student()
	{
	}
	public int getRollNo()
	{
		return rollNo;
	}
	public String getStuName()
	{
		return stuName;
	}
	public int getMarks()
	{
		return marks;
	}
	public void setRollNo(int rollNo)
	{
		this.rollNo = rollNo;
	}
	public void setStuName(String stuName)
	{
		this.stuName = stuName;
	}
	public void setMark( int marks)
	{
		this.marks = marks;
	}
}

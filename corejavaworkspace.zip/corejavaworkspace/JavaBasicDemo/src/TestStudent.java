
public class TestStudent
{
	public static void main(String[] args) 
	{
		Student s1 = new Student();
		s1.setRollNo(111);
		s1.setStuName("Rishab");
		s1.setMark(85);
		
		System.out.println(" Roll No: "+s1.getRollNo());
		System.out.println(" Student Name: "+s1.getStuName());
		System.out.println(" Roll No: "+s1.getMarks());
	}

}


public class Employee
{
	private int eId;
	private String eName;
	private int eSalary;
	private char eGender;
	
	public Employee()
	{
		eId = 0;
		eName = "unknown";
		eSalary = 0;
		eGender = ' ';
		System.out.println("Empty constructor called");
	}
	public Employee(int eId,String eName,int eSalary,char eGender)
	{
		this();
		this.eId = eId;
		this.eName = eName;
		this.eSalary = eSalary;
		this.eGender = eGender;
	}
	public void displayEmployee()
	{
		System.out.println("Employee Id :"+eId);
		System.out.println("Employee Name :"+eName);
		System.out.println("Employee Salary :"+eSalary);
		System.out.println("Employee Gender :"+eGender);
	}
}

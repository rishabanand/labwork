import java.util.Scanner;


public class TestDateDemo {

	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter Day");
		int dayOfDoj = sc.nextInt();
		
		System.out.println("Enter Month");
		int monOfDoj = sc.nextInt();
		
		System.out.println("Enter Year");
		int yearOfDoj = sc.nextInt();
		
		Date rishabDOJ = new Date(dayOfDoj,monOfDoj,yearOfDoj);
		System.out.println(" Your DOJ :"+rishabDOJ.displayDate());
		
		System.out.println("Enter Day");
		int dyOfDoj = sc.nextInt();
		
		System.out.println("Enter Month");
		int mnOfDoj = sc.nextInt();
		
		System.out.println("Enter Year");
		int yrOfDoj = sc.nextInt();
		
		Date divyaDOJ = new Date(dayOfDoj,monOfDoj,yearOfDoj);
		System.out.println(" Your DOJ :"+divyaDOJ.displayDate());
		
	}

}

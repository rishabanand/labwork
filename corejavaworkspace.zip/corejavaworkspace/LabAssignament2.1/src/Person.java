
public class Person 
{
	private String firstName;
	private String lastName;
	private char gender;
	private int age;
	private float weight;
	
	public Person()
	{
		firstName ="unknown";
		lastName = "unknown";
		gender = ' ';
		age = 0;
		weight = 0.0f;
	}
	public Person(String fn,String ln,char gen,int ag,float wt)
	{
		firstName = fn;
		lastName =ln;
		gender =gen;
		age =ag;
		weight =wt;
	}
	public void displayPerson()
	{
		System.out.println("Person Details");
		System.out.println("____________\n");
		System.out.println("First Name :"+firstName);
		System.out.println("last Name :"+lastName);
		System.out.println("Gender :"+gender);
		System.out.println("Age :"+age);
		System.out.println("Weight :"+weight);
	}
}


public class TestPerson 
{
	public static void main(String[] args) 
	{
		Person divya = new Person("Divya","Bharti",'F',20,85.55f);
		divya.displayPerson();

	}
}

package com.cg.mobilepur.dao;

import java.util.ArrayList;

import com.cg.mobilepur.bean.Mobile;
import com.cg.mobilepur.bean.MobilePurchase;
import com.cg.mobilepur.exception.MobileException;


public interface MobileDao 
{
	public int addCustPurDetails(MobilePurchase mobPur) throws MobileException;
	public int updateMobQuanty(int newQuantity,int mobileId) throws MobileException;
	public ArrayList<Mobile> getAllMobileDetails() throws MobileException;
	public int deleteMobDetailById(int mobId) throws MobileException;
	public ArrayList<Mobile> getMobDetailsByPrice(float minprice,float maxprice) throws MobileException;
	public int generatePurchaseId() throws MobileException;
	public ArrayList<Integer> getAllMobileId() throws MobileException;
	public int getMobileQuanty(int mobId) throws MobileException;
}

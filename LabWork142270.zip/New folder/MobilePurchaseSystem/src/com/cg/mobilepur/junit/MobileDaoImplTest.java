package com.cg.mobilepur.junit;
import com.cg.mobilepur.bean.*;
import com.cg.mobilepur.dao.MobileDao;
import com.cg.mobilepur.dao.MobileDaoImpl;
import com.cg.mobilepur.exception.MobileException;

import org.junit.*;

public class MobileDaoImplTest 
{
	static MobileDao mobDao=null;
	static Mobile mob=null;
	static MobilePurchase mobPur=null;
	@BeforeClass
	public static void BeforeClass() throws MobileException
	{
		mobDao=new MobileDaoImpl();
		mobPur =new MobilePurchase();
		mobPur.setCustomerName("Raj");
		mobPur.setMailId("raj@capgemini.com");
		mobPur.setMobileId(1001);
		mobPur.setPhoneno("9906201528");
	}
	@Test
	public  void testAddCustPurchDetail1() throws MobileException
	{
		Assert.assertEquals(1, mobDao.addCustPurDetails(mobPur));
	}
	@Test
	public void testAddCustPurchDetail2() throws MobileException
	{
		Assert.assertEquals(1, mobDao.addCustPurDetails(mobPur));
	}
	@Test 
	public void testGetAllMobileDetail() throws MobileException
	{
		Assert.assertNotNull(mobDao.getAllMobileDetails());
	}
	@Test 
	public void testGetAllMobileDetailByPrice() throws MobileException
	{
		Assert.assertNotNull(mobDao.getMobDetailsByPrice(15000, 38000));
	}
	@Test 
	public void testGetAllMobileDetailById() throws MobileException
	{
		Assert.assertNotNull(mobDao.getAllMobileId());
	}
	public void testGetMobileQuantity() throws MobileException
	{
		Assert.assertNotNull(mobDao.getMobileQuanty(1002));
	}
}

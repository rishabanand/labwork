package com.cg.mobilepur.service;

import java.util.ArrayList;

import com.cg.mobilepur.bean.Mobile;
import com.cg.mobilepur.bean.MobilePurchase;
import com.cg.mobilepur.exception.MobileException;

public interface MobileService
{
	public int addCustPurDetails(MobilePurchase mobPur) throws MobileException;
	public int updateMobQuanty(int newQuantity,int mobileId) throws MobileException;
	public ArrayList<Mobile> getAllMobileDetails() throws MobileException;
	public int deleteMobDetailById(int mobId) throws MobileException;
	public ArrayList<Mobile> getMobDetailsByPrice(float minprice,float maxprice) throws MobileException;
	public int generatePurchaseId() throws MobileException;

	
	
	public boolean validateName(String cName) throws MobileException;
	public boolean validMailId(String mailId) throws MobileException;
	public boolean validPhoneNo(String phoneNo) throws MobileException;
	public boolean validMobileId(int mobileId) throws MobileException;
	public boolean validQuantity(int mobId) throws MobileException;
}


public class MyThread implements Runnable
{
	String msg;
	public MyThread(String msg)
	{
		this.msg=msg;
	}
	@Override
	public void run()
	{
		Thread currThread = Thread.currentThread();
		if(currThread==SleepDemo.t2)
		{
			try 
			{
				SleepDemo.t1.join();
			} 
			catch (InterruptedException e)
			{
				e.printStackTrace();
			}
		}
		for(int i=0;i<3;i++)
		{
		
			System.out.println(currThread.getName()+" Says : "+msg);
		}
		try 
		{
			Thread.sleep(2000);
		}
		catch (InterruptedException e) 
		{
			e.printStackTrace();
		}
	}
}

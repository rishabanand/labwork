package com.cg.lims.ui;

import java.util.Scanner;

import com.cg.lims.Exception.RegistrationException;
import com.cg.lims.bean.BooksRegistration;
import com.cg.lims.service.RegistrationService;
import com.cg.lims.service.UserService;
import com.cg.lims.service.UserServiceImpl;

public class TestLibMgmtSystem
{
	public static void main(String[] args) 
	{
		UserService userService=null;
		RegistrationService regService=null;
		BooksRegistration bookRegi=null;
		int dataAdded=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("lOGIN SCREEN");
		System.out.println("Enter Username :");
		String userName=sc.next();
		System.out.println("Enter Password :");
		String pwd=sc.next();
		userService=new UserServiceImpl();
		try 
		{
			if(userService.validateUser(userName, pwd))
			{
				if(userName.equals("Student") && pwd.equals("Stu"))
				{
					System.out.println("Welcome");
					System.out.println("Choose your Option :");
					System.out.println("1.Book Registration ");
					int choice=sc.nextInt();
					switch(choice)
					{
					case 1:
						System.out.println("Enter Book Id :");
						String bookId=sc.next();
						System.out.println("Enter User Id :");
						String userId=sc.next();
						bookRegi=new BooksRegistration();
						bookRegi.setBookId(bookId);
						bookRegi.setUserId(userId);
						dataAdded=regService.addRegistrationDetails(bookRegi);
						if(dataAdded==1)
						{
							System.out.println("Your request for Book Registration is applied ");
						}
						else
						{
							throw new RegistrationException("Your request fopr Book registration is denied.");
						}
					}
					
				}
					if(userName.equals("library") && pwd.equals("lib"))
					{
						System.out.println("Choose your Option :");
						System.out.println("1.BookTransaction\n 2.Book Inventory");
						int choice=sc.nextInt();
						switch(choice)
						{
						case 1:
							
						case 2:
							
							
						}
						
					}
				}
			
		} 
		catch (Exception e) 
		{			
			e.printStackTrace();
		}

	}
}

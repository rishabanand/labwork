package com.cg.lims.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import com.cg.lims.Exception.RegistrationException;
import com.cg.lims.bean.BooksRegistration;
import com.cg.lims.util.*;

public class RegistrationDaoImpl implements RegistrationDao
{
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;

	@Override
	public int addRegistrationDetails(BooksRegistration register) throws RegistrationException, Exception 
	{
		String insertQry="INSERT INTO BookRegistration VALUES(?,?,?,sysdate)";
		int dataAdded=0;
		try
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(insertQry);
			pst.setInt (1, generateRegistId());
			pst.setString(2, register.getBookId());
			pst.setString(3,register.getUserId());
			dataAdded=pst.executeUpdate();
		}
		catch (Exception e)
		{
			throw new RegistrationException(e.getMessage());
		}
		finally
		{
			try
			{
				pst.close();
				con.close();
			}
			catch (Exception e)
			{     

				throw new RegistrationException(e.getMessage());
			}
		}
		return dataAdded;
	}

	@Override
	public int generateRegistId() throws RegistrationException, Exception 
	{
		String qry="SELECT mob_seq.NEXTVAL FROM DUAL";
		int generatedVal;
		try
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(qry);
			rs.next();
			generatedVal=rs.getInt(1);

		}
		catch (Exception e)
		{e.printStackTrace();
		throw new RegistrationException(e.getMessage());
		}
		finally
		{
			try 
			{
				rs.close();
				st.close();
				con.close();
			} 
			catch (Exception e)
			{e.printStackTrace();
			throw new RegistrationException(e.getMessage());
			}
		}
		return  generatedVal;

	}

	@Override
	public ArrayList<String> getBookId() throws RegistrationException 
	{
		ArrayList<String> booksId=new ArrayList<String>();
		String selectQry=" SELECT book_id FROM BooksInventory ";

		try
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(selectQry);
			while(rs.next())
			{
				String bookId=rs.getString("book_id");
				booksId.add(bookId);
			}
		}
		catch (Exception e)
		{
			throw new RegistrationException(e.getMessage());
		} 
		finally
		{
			try
			{
				rs.close();
				st.close();
				con.close();
			}
			catch (Exception e)
			{
				throw new RegistrationException(e.getMessage());
			}
		}
		return booksId;
	}

	@Override
	public ArrayList<String> getUserId() throws RegistrationException 
	{

		ArrayList<String> userIds=new ArrayList<String>();
		String selectQry=" SELECT user_id FROM Users ";

		try
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(selectQry);
			while(rs.next())
			{
				String userId=rs.getString("user_id");
				userIds.add(userId);
			}
		}
		catch (Exception e)
		{
			throw new RegistrationException(e.getMessage());
		} 
		finally
		{
			try
			{
				rs.close();
				st.close();
				con.close();
			}
			catch (Exception e)
			{
				throw new RegistrationException(e.getMessage());
			}
		}
		return userIds;
	}

}

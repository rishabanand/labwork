package com.cg.lims.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.lims.Exception.BookInventoryException;
import com.cg.lims.bean.BooksInventory;
import com.cg.lims.util.DBUtil;

public class BooksInventoryDaoImpl implements BooksInventoryDao
{
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	Logger limsLogger=null;

	public BooksInventoryDaoImpl()
	{
		PropertyConfigurator.configure("resources/log4j.properties");
		limsLogger=Logger.getLogger("BooksInventoryDaoImpl.class");
	}
	@Override
	public int addBookInventory(BooksInventory bookInv) throws BookInventoryException 
	{
		String insertQry="INSERT INTO BooksInventory VALUES(?,?,?,?,?,?)";
		int dataAdded=0;
		//String userChoice;
		try
		{			
			con=DBUtil.getCon();
			pst=con.prepareStatement(insertQry);
			pst.setString(1, bookInv.getBookId());			
			pst.setString(2, bookInv.getBookName());
			pst.setString(3,bookInv.getAuthor1());
			pst.setString(4,bookInv.getAuthor2());
			pst.setString(5,bookInv.getPublisher());
			pst.setString(6, bookInv.getYearOfPublication());

			dataAdded=pst.executeUpdate();
			limsLogger.log(Level.INFO, "Book Inserted: "+bookInv);

		}
		catch (Exception e)
		{
			throw new BookInventoryException("Problem in inserting data in booksInventory "+e.getMessage());
		}
		finally
		{
			try
			{
				pst.close();
				con.close();
			}
			catch (Exception e)
			{  
				limsLogger.error("This is Exception"+e.getMessage());

				throw new BookInventoryException(e.getMessage());
			}
		}
		return dataAdded;
	}

	@Override
	public String generateBookId() throws BookInventoryException 
	{
		String qry="SELECT 'B'||to_char(book_id_seq.NEXTVAL,'FM00') FROM DUAL";
		String generatedVal;
		try
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(qry);
			rs.next();
			generatedVal=rs.getString(1);

		}
		catch (Exception e)
		{
			throw new BookInventoryException("Problem in generating the book id "+e.getMessage());
		}
		finally
		{
			try 
			{
				rs.close();
				st.close();
				con.close();
			} 
			catch (Exception e)
			{
				throw new BookInventoryException(e.getMessage());
			}
		}
		return  generatedVal;

	}

	@Override
	public int deleteBook(String bId) throws BookInventoryException 
	{
		String qry="DELETE FROM booksinventory WHERE book_id=?";
		int dataDeleted=0;
		try
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(qry);
			pst.setString(1, bId);
			dataDeleted=pst.executeUpdate();

		}
		catch (Exception e)
		{
			throw new BookInventoryException("Problem in deleting book record "+e.getMessage());
		}
		return dataDeleted;
	}

}

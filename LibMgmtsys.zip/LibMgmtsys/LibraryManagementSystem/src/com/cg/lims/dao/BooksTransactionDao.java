package com.cg.lims.dao;

import java.sql.Date;
import java.util.ArrayList;

import com.cg.lims.Exception.BooksTransactionException;
import com.cg.lims.Exception.RegistrationException;
import com.cg.lims.bean.BookTransaction;

public interface BooksTransactionDao 
{
	public String generateTransactionId() throws BooksTransactionException;
	public ArrayList<String> getRegId() throws RegistrationException;
	public int issueBook(BookTransaction bookTransaction) throws BooksTransactionException;
	
	public Date getReturnDate(String registrationId) throws BooksTransactionException;
	public int updateReturnDateAndFine(String registrationId,int fine)throws BooksTransactionException;
	public String getBookIdByRegistrationId(String registrationId)throws BooksTransactionException;
}

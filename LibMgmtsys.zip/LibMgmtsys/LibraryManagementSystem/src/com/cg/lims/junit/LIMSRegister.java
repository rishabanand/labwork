package com.cg.lims.junit;

import java.time.LocalDate;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.lims.Exception.RegistrationException;
import com.cg.lims.Exception.UserException;
import com.cg.lims.bean.BooksRegistration;
import com.cg.lims.dao.RegistrationDao;
import com.cg.lims.dao.RegistrationDaoImpl;
import com.cg.lims.service.RegistrationService;
import com.cg.lims.service.RegistrationServiceImpl;



public class LIMSRegister
{
	static RegistrationDao regdao=new RegistrationDaoImpl();
	static RegistrationService userservice=new RegistrationServiceImpl();
	static BooksRegistration booksreg=new BooksRegistration();
	
	@BeforeClass
	public static void beforeClass() throws UserException
	{
		LocalDate regDate=LocalDate.of(2018, 02, 24);
		
		regdao=new RegistrationDaoImpl();
		booksreg = new BooksRegistration("R12","B08","u01",regDate);
	}
	@Test
	public void testAddBook() throws RegistrationException
	{
		try 
		{
			Assert.assertEquals(1, regdao.addRegistrationDetails(booksreg));
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
}

package com.cg.lims.junit;



import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.lims.Exception.BookInventoryException;
import com.cg.lims.Exception.UserException;
import com.cg.lims.bean.BooksRegistration;
import com.cg.lims.bean.User;
import com.cg.lims.dao.BooksInventoryDao;
import com.cg.lims.dao.BooksInventoryDaoImpl;
import com.cg.lims.dao.RegistrationDao;
import com.cg.lims.dao.RegistrationDaoImpl;
import com.cg.lims.dao.UserDao;
import com.cg.lims.dao.UserDaoImpl;
import com.cg.lims.service.UserService;
import com.cg.lims.service.UserServiceImpl;

public class LIMSUsers
{
	static RegistrationDao regdao=new RegistrationDaoImpl();
	static BooksInventoryDao regdao1=new BooksInventoryDaoImpl();
	static BooksRegistration bookreg=null; 
	static UserDao usrdao=new UserDaoImpl();
	static UserService userservice=new UserServiceImpl();
	static User user=new User();
	@BeforeClass
	public static void beforeClass() throws UserException
	{
		usrdao=new UserDaoImpl();
		 user = new User("u01","Student","stu","stu@gmail.com","n");
	}
	 @Test
	    public void testUsers() throws BookInventoryException
	    {
	       
				try {
					Assert.assertEquals(false,userservice.validateUser(user.getUserName(),user.getPassword()));
				} catch (UserException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			
	    }
}

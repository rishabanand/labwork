package com.cg.lims.junit;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.lims.Exception.BookInventoryException;
import com.cg.lims.Exception.RegistrationException;
import com.cg.lims.bean.BooksRegistration;
import com.cg.lims.dao.BooksInventoryDao;
import com.cg.lims.dao.BooksInventoryDaoImpl;
import com.cg.lims.dao.RegistrationDao;
import com.cg.lims.dao.RegistrationDaoImpl;

public class LIMSjunit 
{
	static RegistrationDao regdao=new RegistrationDaoImpl();
	static BooksInventoryDao regdao1=new BooksInventoryDaoImpl();
	static BooksRegistration bookreg=null; 
	
	@BeforeClass
	public static void beforeClass() throws RegistrationException
	{
		regdao=new RegistrationDaoImpl();
//		String  regDate=;
//		DateTimeFormatter myFormat= DateTimeFormatter.ofPattern("dd-MM-YY")	;	
//		LocalDate regDate1=LocalDate.parse(regDate, myFormat);
//		
		LocalDate regDate=LocalDate.of(2018, 02, 24);
		try 
		{
			bookreg = new BooksRegistration("R15","B08","u01",regDate);
		} 
		catch (Exception e) 
		{
			throw new RegistrationException(e.getMessage());
			
		}
		
		
	}
	@Test
	public void testAddBook() throws RegistrationException
	{
		try 
		{
			Assert.assertEquals(1, regdao.addRegistrationDetails(bookreg));
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
	 @Test
	    public void testdelete() throws BookInventoryException
	    {
	    	String BookId = "B08";
	        Assert.assertEquals(1, regdao1.deleteBook(BookId));
	    }
	
}

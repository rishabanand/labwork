package com.cg.lims.service;




import com.cg.lims.Exception.UserException;

public interface UserService
{
	public boolean validateUser(String userName,String password)  throws Exception, UserException;
	public String getLibrarianValueByUserName(String userName) throws UserException;
} 

package com.cg.lims.service;

import com.cg.lims.Exception.BookInventoryException;
import com.cg.lims.bean.BooksInventory;
import com.cg.lims.dao.BooksInventoryDao;
import com.cg.lims.dao.BooksInventoryDaoImpl;

public class BooksInventoryServiceImpl implements BooksInventoryService 
{
	BooksInventoryDao bookInvDao=new BooksInventoryDaoImpl();

	@Override
	public int addBookInventory(BooksInventory bookInv)
			throws BookInventoryException 
	{		
		return bookInvDao.addBookInventory(bookInv);
	}

	@Override
	public String generateBookId() throws BookInventoryException
	{
		return bookInvDao.generateBookId();
	}

	@Override
	public int deleteBook(String bId) throws BookInventoryException 
	{		
		return bookInvDao.deleteBook(bId);
	}

}

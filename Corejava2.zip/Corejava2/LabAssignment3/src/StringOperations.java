import java.util.Scanner;


public class StringOperations 
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a String");
		String name =sc.next();
		System.out.println("Enter a choice");
		System.out.println("1.Concatenation\n2.Replacing odd characters with #\n3.Converting the odd characters into Uppercase");
		int  choice = sc.nextInt();
		switch(choice)
		{
		case 1: 	
			String catString = name + name;
			System.out.println("The concatenated String is :"+catString);
			break;
		case 2:
			for(int i=0;i<name.length();i++)
			{
				char currChar =name.charAt(i);
				if(i%2==1)
				{
					name = name.replace(currChar, '#');
				}
			}
			System.out.println(name);
			break;
		case 3:
			String name2 = name.toUpperCase();
			for(int i=0;i<name.length();i++)
			{
				
				char [] ch =name2.toCharArray();
				if(i%2==1)
				{
					name2 = name2 + ch[i];
				}
			}
			System.out.println(name2);
			break;
		}
	}
}

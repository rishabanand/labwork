public class Tablet extends Medicine
{
	private String msg="Store in a cool and Dry Place";
	public Tablet()
	{
		super();
	}
	public Tablet(String medName, String compName, String expireDate,
			float price,String msg)
	{
		super(medName,compName,expireDate,price);
		this.msg=msg;
	}
	public String disMedicineInfo()
	{
		return null;
	}
}

import java.util.Scanner;


public class TestMedicine
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the no of Medicine");
		int medCount = sc.nextInt();
		Medicine medArr[]=new Medicine[medCount];
		String mName = null;
		String cName = null;
		String eDate = null;
		float prz = 0.0f;
		for(int i=0;i<medArr.length;i++)
		{
			System.out.println("Enter the Medicine Name:");
			mName = sc.next();
			System.out.println("Enter the Company Name");
			cName = sc.next();
			System.out.println("Enter the expiry Date");
			eDate = sc.next();
			System.out.println("Enter the Price");
			prz= sc.nextFloat();
			
			System.out.println("Choose Type of Medicine for"+mName+"1.Tablet\t2:Ointment\t3.Syrup");
			System.out.println("Enter Choice");
			int choice=sc.nextInt();
			switch(choice)
			{
			case 1: 
				medArr[i]=new Medicine(mName,cName,eDate, prz);
				break;
			case 2:
				medArr[i]=new Medicine(mName,cName,eDate, prz);
			default:
				medArr[i]=new Medicine(mName,cName,eDate, prz);
			}
		}
		for(int j=0;j<medArr.length;j++)
		{
			if(medArr[j] instanceof Syrup)
			{
				System.out.println(" Syrup :"+medArr[j].disMedicineInfo());
			}
			else if(medArr[j] instanceof Tablet)
			{
				System.out.println(" Tablet :"+medArr[j].disMedicineInfo());
			}
			else if(medArr[j] instanceof Ointment)
			{
				System.out.println(" Ointment :"+medArr[j].disMedicineInfo());
			}
			else
			{
				System.out.println(" Medicine :"+medArr[j].disMedicineInfo());
			}
		}
	}

}

import java.time.*;
import java.util.Calendar;

public class Date
{
	public static void main(String[] args) 
	{
		System.out.println(java.time.LocalDate.now()); 
		 
		 Year y = Year.now();  
		    System.out.println(y);
		    Date today = new Date();  
		   
		    Calendar cal = Calendar.getInstance(); 
		    int dayOfWeek = cal.get(Calendar.DAY_OF_WEEK); 
		    int dayOfMonth = cal.get(Calendar.DAY_OF_MONTH); 
		    int dayOfYear = cal.get(Calendar.DAY_OF_YEAR); 
		    int month = cal.get(Calendar.MONTH); 
		    int year = cal.get(Calendar.YEAR); // 2016
		    System.out.println(month+"\n"+year+"\n"+dayOfMonth);
		   
		    LocalDate currentDate = LocalDate.now();
		    DayOfWeek dow = currentDate.getDayOfWeek(); 
		    int dom = currentDate.getDayOfMonth(); 
		    int doy = currentDate.getDayOfYear(); 
		    Month m = currentDate.getMonth();
		    int yr = currentDate.getYear(); 

		       System.out.println(m);
		       System.out.println(yr);
		       System.out.println(dom);
	}
}
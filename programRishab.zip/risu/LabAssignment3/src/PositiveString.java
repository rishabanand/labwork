import java.util.Arrays;


public class PositiveString 
{
public static void main(PositiveString[] args) 
	{
		String str="Rishab";
		String str1=str;
		char [] tempArray = str1.toCharArray();
		StringBuilder sb = new StringBuilder(tempArray.length);
        for (Character c : tempArray)
            sb.append(c.charValue());
	
		Arrays.sort(tempArray);
		System.out.println(sb.toString());
		if(str1==sb.toString())
		{
			System.out.println("The string is positive");
		}
	}

}

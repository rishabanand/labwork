package com.cg.lims.exception;

public class BooksTransactionException extends Exception
{
	private static final long serialVersionUID = 1L;

	public BooksTransactionException() 
	{
		super();
	}

	public BooksTransactionException(String arg0, Throwable arg1, boolean arg2,
			boolean arg3)
	{
		super(arg0, arg1, arg2, arg3);		
	}

	public BooksTransactionException(String arg0, Throwable arg1)
	{
		super(arg0, arg1);
	}

	public BooksTransactionException(String arg0)
	{
		super(arg0);
	}

	public BooksTransactionException(Throwable arg0) 
	{
		super(arg0);
	}

}

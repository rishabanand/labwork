package com.cg.lims.bean;

import java.time.LocalDate;

public class BookTransaction 
{
	private String transactionId;
	private String registrationId;
	private LocalDate issueDate;
	private LocalDate returnDate;
	private int fine;
	public String getTransactionId()
	{
		return transactionId;
	}
	public void setTransactionId(String transactionId) 
	{
		this.transactionId = transactionId;
	}
	public String getRegistrationId() 
	{
		return registrationId;
	}
	public void setRegistrationId(String registrationId) 
	{
		this.registrationId = registrationId;
	}
	public LocalDate getIssueDate() 
	{
		return issueDate;
	}
	public void setIssueDate(LocalDate issueDate) 
	{
		this.issueDate = issueDate;
	}
	public LocalDate getReturnDate() 
	{
		return returnDate;
	}
	public void setReturnDate(LocalDate returnDate)
	{
		this.returnDate = returnDate;
	}
	public int getFine()
	{
		return fine;
	}
	public void setFine(int fine)
	{
		this.fine = fine;
	}
	public BookTransaction() 
	{
		super();
	}
	public BookTransaction(String transactionId, String registrationId,
			LocalDate issueDate, LocalDate returnDate, int fine) 
	{
		super();
		this.transactionId = transactionId;
		this.registrationId = registrationId;
		this.issueDate = issueDate;
		this.returnDate = returnDate;
		this.fine = fine;
	}
	@Override
	public String toString() 
	{
		return "BookTransaction [transactionId=" + transactionId
				+ ", registrationId=" + registrationId + ", issueDate="
				+ issueDate + ", returnDate=" + returnDate + ", fine=" + fine
				+ "]";
	}
	
}

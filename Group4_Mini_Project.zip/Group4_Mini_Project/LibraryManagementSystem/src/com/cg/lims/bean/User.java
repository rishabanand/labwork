package com.cg.lims.bean;

public class User 
{
	private String userId;
	private String userName;
	private String password;
	private String emailId;
	private String librarian;
	public User() 
	{
		super();
		
	}
	public User(String userId, String userName, String password,
			String emailId, String librarian) 
	{
		super();
		this.userId = userId;
		this.userName = userName;
		this.password = password;
		this.emailId = emailId;
		this.librarian = librarian;
	}
	public String getUserId()
	{
		return userId;
	}
	public void setUserId(String userId) 
	{
		this.userId = userId;
	}
	public String getUserName() 
	{
		return userName;
	}
	public void setUserName(String userName) 
	{
		this.userName = userName;
	}
	public String getPassword() 
	{
		return password;
	}
	public void setPassword(String password) 
	{
		this.password = password;
	}
	public String getEmailId() 
	{
		return emailId;
	}
	public void setEmailId(String emailId)
	{
		this.emailId = emailId;
	}
	public String getLibrarian() 
	{
		return librarian;
	}
	public void setLibrarian(String librarian) 
	{
		this.librarian = librarian;
	}
	@Override
	public String toString() 
	{
		return "User [userId=" + userId + ", userName=" + userName
				+ ", password=" + password + ", emailId=" + emailId
				+ ", librarian=" + librarian + "]";
	}
	
}

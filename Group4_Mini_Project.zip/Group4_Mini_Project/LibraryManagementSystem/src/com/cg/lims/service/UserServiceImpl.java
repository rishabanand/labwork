package com.cg.lims.service;

import java.util.ArrayList;

import com.cg.lims.dao.UserDao;
import com.cg.lims.dao.UserDaoImpl;
import com.cg.lims.exception.UserException;

public class UserServiceImpl implements UserService
{
	UserDao userDao=null;

	public UserServiceImpl()
	{
		userDao=new UserDaoImpl();
	}
	@Override
	public boolean validateUser(String userName,String password) throws Exception, UserException 
	{
		if(validateUserName(userName) && validatePassword(password))
		{			
			return true;
		}
		throw new UserException("Please check your username and password ");	
	}
	private boolean validateUserName(String userName) throws UserException, Exception
	{
		ArrayList<String> userNames=userDao.getUserName();
		for(String tempbookIds :userNames)
		{
			if(userName.equals(tempbookIds))
			{
				return true;
			}
		}
		return false;		
	}
	private boolean validatePassword(String password) throws UserException, Exception
	{
		ArrayList<String> pwds=userDao.getUserPwd();		
		for(String tempPwds :pwds)
		{
			if(password.equals(tempPwds))
			{
				return true;
			}
		}
		return false;		
	}
	@Override
	public String getLibrarianValueByUserName(String userName)
			throws UserException
	{		
		return userDao.getLibrarianValueByUserName(userName);
	}
	@Override
	public String getUserNameByUserName(String userName) throws UserException 
	{
		
		return userDao.getUserNameByUserName(userName);
	}
}

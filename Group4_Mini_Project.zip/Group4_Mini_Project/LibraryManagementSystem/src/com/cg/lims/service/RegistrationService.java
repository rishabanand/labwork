package com.cg.lims.service;

import com.cg.lims.bean.BooksRegistration;
import com.cg.lims.exception.RegistrationException;

public interface RegistrationService
{
	public int addRegistrationDetails(BooksRegistration register)throws RegistrationException,Exception;
	public boolean validateIds(String userId,String BookId) throws RegistrationException;
	public String generateRegistId() throws RegistrationException, Exception ;
	public boolean validateBookId(String bookId) throws RegistrationException;
}

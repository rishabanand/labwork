import java.time.LocalDate;
import java.time.Month;
import java.time.format.DateTimeFormatter;


public class Fine1 {

	public static void main(String[] args) 
	{
		//LocalDate currentDate=LocalDate.now();
		//System.out.println(currentDate);
		
		String returnDate="2018,02,24";
		DateTimeFormatter myFormat=DateTimeFormatter.ofPattern("yyyy,MM,dd");
		LocalDate date2=LocalDate.parse(returnDate,myFormat);
		int month=date2.getMonthValue();
		System.out.println("Month is  :"+month);
		int year=date2.getYear();
		System.out.println("Year is  :"+year);
		int date=date2.getDayOfMonth();
		System.out.println("Day is  :"+date);
		LocalDate currDate=LocalDate.of(year, month, date);	
		//System.out.println("Date is :"+currDate);
		/*
		if(currentDate.getDayOfYear()>returnDate.getDayOfYear())
		{
			
			int diff=currentDate.getDayOfYear()-returnDate.getDayOfYear();
			System.out.println("dIFFERENCE IS :"+diff);
			int fine=1*(currentDate.getDayOfYear()-returnDate.getDayOfYear());
			System.out.println("Fine is  : "+fine);
		}*/
		

	}

}

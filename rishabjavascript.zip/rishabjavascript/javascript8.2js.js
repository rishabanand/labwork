
	var prodArr=[["Television","Laptop","Phone"],["Soap","Powder"]];
function populateProduct()
{
	var category = frm1.category.value;
	var categoryIdx = frm1.category.selectedIndex;
	var Product = frm1.product;
	for(i=0;i<prodArr[categoryIdx-1].length;i++)
	{
		var productOption = new Option();
		productOption.text = prodArr[categoryIdx-1][i];    //getting inner text 
		Product.options[i+1]=productOption;
	}
}
function calculateTotalprice()
{
	var quantity = frm1.qty.value;
	
	if(productArr[0]=='Televison')
	{
		var totalprice = quantity * 20000; 
	}
	else if(prodArr[0] == 'Laptop')
	{
		var totalprice = quantity * 30000;		
	}
	else if(prodArr[0] == 'Phone')
	{
		var totalprice = quantity * 10000;		
	}
	else if(prodArr[1] == 'Soap')
	{
		var totalprice = quantity * 40;		
	}
	else if(prodArr[1] == 'Powder')
	{
		var totalprice = quantity * 90;		
	}
	//frm1.price.value = totalprice;
	alert("The total price is "+totalprice);
}

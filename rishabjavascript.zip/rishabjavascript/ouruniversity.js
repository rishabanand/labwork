function validatescholar()
{
	//alert("enter");
	var cour=document.university.course.value;
	alert(cour);
	var guide=document.university.s1.value;
	alert(guide);
	var rno=document.getElementById("rollno").value;
	alert(rno);
	var fnm=document.getElementById("fname").value;
	alert(fnm);
	var lnm=document.getElementById("lname").value;
	alert(lnm);
	var rdate=document.getElementById("regdate").value;
	alert(rdate);
	var phone=document.getElementById("mobile").value;
	alert(phone);
	var rtopic=document.getElementById("research").value;
	alert(rtopic);
	var addr=document.getElementById("address").value;
	alert(addr);
	
	if(cour=="" || cour==null)
		{
		alert("Please Select one course");
		return false;
		}
	if(guide=="" || guide==null)
		{
		alert("Please select guide name");
		return false;
		}
	alert("Roll No :"+rno+"\n First Name : "+fnm+"\n Last Name : "+lnm+"\n Course : "+cour+"\n Registration Date : "+rdate+"\n Mobile : "+phone+"\n Research Topic : "+rtopic+"\n Guide Name :"+guide+"\n Permanent Address: "+addr);
	
	  var myWindow = window.open("", "MsgWindow", "width=400,height=400");
	  myWindow.document.write("<table border='2'><tr><td>Roll Number</td><td>"+rno+"</td></tr><tr><td>First Name</td><td>"+fnm+"</td></tr><tr><td>Last Name</td><td>"+lnm+"</td></tr><tr><td>course name</td><td>"+cour+"</td></tr><tr><td>Registration date</td><td>"+rdate+"</td></tr><tr><td>Mobile</td><td>"+phone+"</td></tr><tr><td>Research Topic</td><td>"+rtopic+"</td></tr><tr><td>Guide Name</td><td>"+guide+"</td></tr><tr><td>permanent Address</td><td>"+addr+"</table>");
	  
	return true;
	}











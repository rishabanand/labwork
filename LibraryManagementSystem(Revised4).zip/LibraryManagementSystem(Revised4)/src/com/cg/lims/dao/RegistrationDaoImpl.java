package com.cg.lims.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.lims.Exception.RegistrationException;
import com.cg.lims.bean.BooksRegistration;
import com.cg.lims.util.*;

public class RegistrationDaoImpl implements RegistrationDao
{
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	Logger limsLogger=null;

	public RegistrationDaoImpl()
	{
		PropertyConfigurator.configure("resources/log4j.properties");
		limsLogger=Logger.getLogger("RegistrationDaoImpl.class");
	}

	@Override
	public int addRegistrationDetails(BooksRegistration register) throws RegistrationException, Exception 
	{
		String insertQry="INSERT INTO BooksRegistration VALUES(?,?,?,sysdate)";
		int dataAdded=0;
		try
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(insertQry);
			pst.setString (1, register.getRegistrationId());
			pst.setString(2, register.getBookId());
			pst.setString(3,register.getUserId());
			dataAdded=pst.executeUpdate();
			limsLogger.log(Level.INFO, "Book Registered: "+register);
		}
		catch (Exception e)
		{
			throw new RegistrationException(e.getMessage());
		}
		finally
		{
			try
			{
				pst.close();
				con.close();
			}
			catch (Exception e)
			{     
				limsLogger.error("This is Exception"+e.getMessage());
				throw new RegistrationException(e.getMessage());
			}
		}
		return dataAdded;
	}

	@Override
	public String generateRegistId() throws RegistrationException, Exception 
	{
		String qry="SELECT 'R'||to_char(reg_id_seq.NEXTVAL,'FM00') FROM DUAL";
		String generatedVal;
		try
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(qry);
			rs.next();
			generatedVal=rs.getString(1);

		}
		catch (Exception e)
		{			
			throw new RegistrationException(e.getMessage());
		}
		finally
		{
			try 
			{
				rs.close();
				st.close();
				con.close();
			} 
			catch (Exception e)
			{				
				throw new RegistrationException(e.getMessage());
			}
		}
		return  generatedVal;

	}

	@Override
	public ArrayList<String> getBookId() throws RegistrationException 
	{
		ArrayList<String> booksId=new ArrayList<String>();
		String selectQry=" SELECT book_id FROM BooksInventory ";

		try
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(selectQry);
			while(rs.next())
			{
				String bookId=rs.getString("book_id");
				booksId.add(bookId);
			}
		}
		catch (Exception e)
		{
			throw new RegistrationException(e.getMessage());
		} 
		finally
		{
			try
			{
				rs.close();
				st.close();
				con.close();
			}
			catch (Exception e)
			{
				throw new RegistrationException(e.getMessage());
			}
		}
		return booksId;
	}

	@Override
	public ArrayList<String> getUserId() throws RegistrationException 
	{

		ArrayList<String> userIds=new ArrayList<String>();
		String selectQry=" SELECT user_id FROM Users ";

		try
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(selectQry);
			while(rs.next())
			{
				String userId=rs.getString("user_id");
				userIds.add(userId);
			}
		}
		catch (Exception e)
		{
			throw new RegistrationException(e.getMessage());
		} 
		finally
		{
			try
			{
				rs.close();
				st.close();
				con.close();
			}
			catch (Exception e)
			{
				throw new RegistrationException(e.getMessage());
			}
		}
		return userIds;
	}

	


	}

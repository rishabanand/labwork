package com.cg.jdbc.demo;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
public class InsertDemo {
	
	public static void main(String[] args) {
		Connection con=DatabaseConnection.getConnection();
		String insQuery="insert into employee_masters"+"(empid,empname,salary,joindate,deptid)"
		+" values(emp_id_seq.nextval,?,?,sysdate,?)";
		
		try
		{
			PreparedStatement ps=con.prepareStatement(insQuery);
			
			//ps.setInt(1,2);
			ps.setString(1,"ajitha");
			ps.setDouble(2, 34000.00);
			
			//LocalDate jdate=LocalDate.of(2016, 5, 4);
			//ps.setDate(4,Date.valueOf(jdate));
			ps.setInt(3, 3);
			int r=ps.executeUpdate();
			
			String sql="select emp_id_seq.currval from dual";
			Statement stmt=con.createStatement();
			ResultSet rs=stmt.executeQuery(sql);
			int empid=0;
			if(rs.next())
				empid=rs.getInt(1);
			System.out.println("EMPLOYEE RECORD INSERTED WITH EMPID:"+empid);
			
			System.out.println(r +"rows inserted...");
		
		}catch(SQLException e)
		{
			e.printStackTrace();
		}
	}

}

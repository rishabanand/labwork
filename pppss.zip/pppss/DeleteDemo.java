package com.cg.jdbc.demo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DeleteDemo {
	
	public static void main(String[] args) {
		Connection con=DatabaseConnection.getConnection();
		String delQuery=" DELETE FROM employee_masters where deptid=?"; 
		PreparedStatement ps;
		try
		{
			ps=con.prepareStatement(delQuery);
		    ps.setInt(1, 3);
		    int r=ps.executeUpdate();
		System.out.println(r +"rows deleted");
		
		}catch(SQLException e)
		{
			e.printStackTrace();
		}
		
	}

}

package com.cg.contact.ui;

import java.util.Scanner;

import com.cg.contact.bean.ApplicantBean;
import com.cg.contact.exception.ApplicantException;
import com.cg.contact.service.ApplyService;
import com.cg.contact.service.ApplyServiceImpl;

public class Client 
{
	static ApplyService applyService=new ApplyServiceImpl();;
	static Scanner sc=null;
	static ApplicantBean applicant=null;
	public static void main(String[] args) 
	{
		
		 sc=new Scanner(System.in);
		
			
			int choice=0;
			while(true)
			{
				System.out.println("Select an operation ");
				System.out.println("1.Enter Details \n2.View Details based on Applicant Id \n0.Exit");
				System.out.println("Please enter a choice : ");
				choice=sc.nextInt();
				switch(choice)
				{
				case 1:	addApplicantDetails();	
						break;
					
				case 2:	getApplicantDetailsById();
						break;
				case 0: exit();
				
						break;
					
				default : System.out.println("Invalid Choice Enter");
					
				}
			}
		

	}
	public static void addApplicantDetails() 
	{
		int dataAdded=0;
		System.out.println("Enter First Name: ");
		String fName=sc.next();
		System.out.println("Enter Last Name: ");
		String lName=sc.next();
		System.out.println("Enter Contact Number: ");
		long contactNo=sc.nextLong();
		System.out.println("Enter Email: ");
		String emailId=sc.next();
		System.out.println("Enter Aggregate in qualifying exam:");
		float agg=sc.nextFloat();
		System.out.println("Enter Stream: ");
		String stream=sc.next();
		applicant =new ApplicantBean();
		try 
		{
			applicant.setApplyId(applyService.generateApplyId());
			applicant.setfName(fName);
			applicant.setlName(lName);
			applicant.setContactNo(contactNo);
			applicant.setEmail(emailId);
			applicant.setAggregate(agg);
			applicant.setStream(stream);
			if(applyService.isValidApplicant(applicant))
			{
				
				dataAdded=applyService.addApllicantDetails(applicant);
				if(dataAdded==1)
				{
					System.out.println("Thank you "+applicant.getfName()+" "+applicant.getlName()
							+"your Unique Id is "+applicant.getApplyId()+
							" "+"we will contact you shortly");
				}
				else
				{
					System.out.println("May Have some exception while Inserting Data");
				}
				
			}
		}
		catch (ApplicantException e) 
		{
			System.out.println(e.getMessage());
		}
		
	}
	public static void getApplicantDetailsById()
	{
		try 
		{
			System.out.println("Enter your Unique Id :");
			long applyId=sc.nextLong();
		
			System.out.println(applyService.getApplicantDetails(applyId));
			
		} 
		catch (ApplicantException e) 
		{			
			System.out.println(e.getMessage());
		}
		
	}
	public static void exit() 
	{
		System.out.println("Thank you for applying !!");
		System.exit(0);
	}
}

public class TestIf
{
	public static void main(String ar[])
	{
		int marks=Integer.parseInt(ar[0]);
		if(marks<40)
			System.out.println("You are fail");
		else if((marks>=40)&&(marks<60))
			System.out.println("You are fail");
		else if((marks>=60)&&(marks<75))
			System.out.println("You are firstclass");
		else if((marks>=75)&&(marks<100))
			System.out.println("You got Distinction");
		else
			System.out.println("Invalid marks");
	}
}
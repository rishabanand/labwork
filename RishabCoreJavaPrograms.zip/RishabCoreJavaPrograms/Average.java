class Average
{
	public static void main(String ar[])
	{
		int i,length;
		float avg=0,sum=0;
		length = Integer.parseInt(ar[0]);
		for(i=0;i<length;i++)
		{
			sum	= sum + Float.parseFloat(ar[i]);
			avg = sum / length;
		}
		System.out.println("The average of numbers is "+avg);
	}	

}
package com.cg.mobilepur.bean;

import java.sql.Date;

public class MobilePurchase 
{
	private int purchaseId ;
	private String customerName;
	private String phoneno;
	private Date purchaseDate;
	private int mobileId;
	private String mailId;
	
	
	public String getMailId() 
	{
		return mailId;
	}


	public void setMailId(String mailId)
	{
		this.mailId = mailId;
	}


	public MobilePurchase() 
	{
		super();
	}


	public MobilePurchase(int purchaseId, String customerName, String phoneno,
			Date purchaseDate, int mobileId) 
	{
		super();
		this.purchaseId = purchaseId;
		this.customerName = customerName;
		this.phoneno = phoneno;
		this.purchaseDate = purchaseDate;
		this.mobileId = mobileId;
	}


	public int getPurchaseId()
	{
		return purchaseId;
	}


	public void setPurchaseId(int purchaseId) 
	{
		this.purchaseId = purchaseId;
	}


	public String getCustomerName()
	{
		return customerName;
	}


	public void setCustomerName(String customerName) 
	{
		this.customerName = customerName;
	}


	public String getPhoneno() 
	{
		return phoneno;
	}


	public void setPhoneno(String phoneno) 
	{
		this.phoneno = phoneno;
	}

	public int getMobileId() 
	{
		return mobileId;
	}


	public void setMobileId(int mobileId) 
	{
		this.mobileId = mobileId;
	}


	@Override
	public String toString() 
	{
		return "MobilePurchase [purchaseId=" + purchaseId + ", customerName="
				+ customerName + ", phoneno=" + phoneno + ", purchaseDate="
				+ purchaseDate + ", mobileId=" + mobileId + "]";
	}
	
	
}

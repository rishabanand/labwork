package com.cg.mobilepur.service;

import java.util.ArrayList;
import java.util.regex.Pattern;
import com.cg.mobilepur.bean.Mobile;
import com.cg.mobilepur.bean.MobilePurchase;
import com.cg.mobilepur.dao.MobileDao;
import com.cg.mobilepur.dao.MobileDaoImpl;
import com.cg.mobilepur.exception.MobileException;

public class MobileServiceImpl implements MobileService
{	
	MobileDao mobDao=null;

	public MobileServiceImpl() 
	{
		mobDao=new MobileDaoImpl();
	}

	@Override
	public int addCustPurDetails(MobilePurchase mobPur) throws MobileException 
	{
		
		return mobDao.addCustPurDetails(mobPur);
	}

	@Override
	public int updateMobQuanty(int newQuantity, int mobileId)
			throws MobileException
	{
		
		return mobDao.updateMobQuanty(newQuantity, mobileId);
	}

	@Override
	public ArrayList<Mobile> getAllMobileDetails() throws MobileException
	{
		
		return mobDao.getAllMobileDetails();
	}

	@Override
	public int deleteMobDetailById(int mobId) throws MobileException {
		
		return mobDao.deleteMobDetailById(mobId);
	}

	@Override
	public ArrayList<Mobile> getMobDetailsByPrice(float minprice, float maxprice)
			throws MobileException 
	{
	
		return mobDao.getMobDetailsByPrice(minprice, maxprice);
	}

	@Override
	public int generatePurchaseId() throws MobileException 
	{
		
		return mobDao.generatePurchaseId();
	}

	@Override
	public boolean validateName(String cName) throws MobileException 
	{
		String namePattern="[A-Z][a-z]{2,19}";
		if(Pattern.matches(namePattern, cName))
		{
			return true;
		}
		else
		{
			throw new MobileException("Only Chars Allowed and starts with Capital"
					+ " and maximum 20 chracters e.g Rishab");
		}
	}

	@Override
	public boolean validMailId(String mailId) throws MobileException
	{
		String emailPattern="[A-Za-z]+[@][A-Za-z]+[.]com";
		if(Pattern.matches(emailPattern, mailId))
		{
			return true;
		}
		else
		{
			throw new MobileException("In valid email Id. It must be like abcd@gmail.com");
		}
	}

	@Override
	public boolean validPhoneNo(String phoneNo) throws MobileException
	{
		String numPattern="[7-9][0-9]{9}";
		if(Pattern.matches(numPattern, phoneNo))
		{
			return true;
		}
		else
		{
			throw new MobileException("10 digits are required");
		}
	}

	@Override
	public boolean validMobileId(int mobileId) throws MobileException 
	{
		
		String numPattern="[1][0-9]{3}";
		int flag=0;
		if(Pattern.matches(numPattern, new Integer(mobileId).toString()))
		{
			ArrayList<Integer> mobIdList=mobDao.getAllMobileId();
			for(int tempMobIdList :mobIdList)
			{
				if(mobileId==tempMobIdList)
				{
					flag =1;
				}
			}
		}
		if(flag==1)
		{
			return true;
		}
		else
		{
			throw new MobileException("Enter Valid Mobile Id and Mobile Id should have only 4 digits");
		}
	}

	@Override
	public boolean validQuantity(int mobId) throws MobileException
	{
		int mQuan=mobDao.getMobileQuanty(mobId);
		//System.out.println("Hii 3"+mQuan);
		
		if(mQuan>0)
		{
			return true;
		}
		else
		{
			throw new MobileException("Not in Stock");
		}
	}
}

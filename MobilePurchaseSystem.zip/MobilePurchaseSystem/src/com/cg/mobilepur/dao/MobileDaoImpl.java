package com.cg.mobilepur.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.cg.mobilepur.exception.MobileException;
import com.cg.mobilepur.util.DBUtil;
import com.cg.mobilepur.bean.Mobile;
import com.cg.mobilepur.bean.MobilePurchase;

public class MobileDaoImpl implements MobileDao
{
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	@Override
	public int addCustPurDetails(MobilePurchase mobPur) throws MobileException 
	{
		String purchaseDate="Select sysdate from dual";
		String insertQry="INSERT INTO purchasedetails VALUES(?,?,?,?,sysdate,?)";
		int dataAdded=0;
		try 
		{
			con=DBUtil.getCon();
			System.out.println("******************"+con);
			pst=con.prepareStatement(insertQry);
			pst.setInt(1, generatePurchaseId());
			pst.setString(2, mobPur.getCustomerName());
			pst.setString(3, mobPur.getMailId());
			pst.setString(4, mobPur.getPhoneno());
			pst.setInt(5,mobPur.getMobileId());
			dataAdded=pst.executeUpdate();
		}
		catch (Exception e)
		{
			throw new MobileException(e.getMessage());			
		} 
		finally
		{
			try 
			{
				pst.close();
				con.close();
			}
			catch (Exception e)
			{
				throw new MobileException(e.getMessage());
			}
		}
		return dataAdded;
	
	}

	@Override
	public int updateMobQuanty(int newQuantity,int mobileId) throws MobileException 
	{
		String updateQry="UPDATE TABLE mobiles SET (quantity=quantity-?) WHERE mobileid=mobileId";
		int dataUpdated=0;
		try
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(updateQry);
			pst.setInt(1,newQuantity);
			dataUpdated=pst.executeUpdate();
		} 
		catch (Exception e) 
		{			
			throw new MobileException(e.getMessage());
		}
		finally
		{
			try 
			{
				pst.close();
				con.close();
			} 
			catch (SQLException e)
			{
				throw new MobileException(e.getMessage());
			}
		}
		
		return dataUpdated;
	}

	@Override
	public ArrayList<Mobile> getAllMobileDetails() throws MobileException
	{
		
		ArrayList<Mobile> mobList=new ArrayList<Mobile>();
		String selectQry="SELECT * FROM mobiles";
		Mobile m=null;
		try 
		{			
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(selectQry);
			while(rs.next())
			{
				m=new Mobile(rs.getInt("mobileid"),rs.getString("name"),rs.getFloat("price"),rs.getInt("quantity"));
				mobList.add(m);
			}
		} 
		catch (Exception e) 
		{			
			throw new MobileException(e.getMessage());
		}
		finally
		{
			try 
			{
				rs.close();
				st.close();
				con.close();
			} 
			catch (SQLException e)
			{
				throw new MobileException(e.getMessage());//wrapping the other exception and then throw
			}
		}
		return mobList;
	}

	@Override
	public int deleteMobDetailById(int mobId) throws MobileException
	{
		
		String deleteQry="DELETE FROM  mobiles WHERE mobileid=?";
		int dataDeleted=0;
		try 
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(deleteQry);
			pst.setInt(1, mobId);
			dataDeleted=pst.executeUpdate();
		} 
		catch (Exception e) 
		{					
			throw new MobileException(e.getMessage());
		}
		finally
		{
			try 
			{
				pst.close();
				con.close();
			} 
			catch (SQLException e)
			{
				throw new MobileException(e.getMessage());
			}
		}
		return dataDeleted;
	}

	@Override
	public ArrayList<Mobile> getMobDetailsByPrice(float minprice,float maxprice)
			throws MobileException 
	{
		ArrayList<Mobile> mobList=new ArrayList<Mobile>();
		String selectRangeQuery="SELECT * FROM mobiles "
				+ "WHERE price between ? and ?  ";
		Mobile mob=null;
		try
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(selectRangeQuery);
			pst.setFloat(1, minprice);
			rs=pst.executeQuery();
			while(rs.next())
			{		
				mob=new Mobile(rs.getInt("mobileid"),rs.getString("name"),rs.getFloat("price"),rs.getInt("quantity"));
				mobList.add(mob);
			}
		} 
		catch (Exception e) 
		{
			throw new MobileException(e.getMessage());
		}
		finally
		{
			try 
			{
				rs.close();
				st.close();
				con.close();
			} 
			catch (SQLException e)
			{
				throw new MobileException(e.getMessage());//wrapping the other exception and then throw
			}
		}
		
		return mobList;
	}

	@Override
	public int generatePurchaseId() throws MobileException 
	{
		String qry="Select pur_seq.NEXTVAL FROM DUAL";
		int generatedVal=0;
		try 
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(qry);
			rs.next();
			generatedVal=rs.getInt(1);
		}
		catch (Exception e) 
		{
			throw new MobileException(e.getMessage());
		} 
		finally
		{
			try 
			{
				rs.close();
				st.close();
				con.close();
			} 
			catch (SQLException e)
			{
				throw new MobileException(e.getMessage());
			}
		}
		return generatedVal;
	}

	@Override
	public ArrayList<Integer> getAllMobileId() throws MobileException 
	{
		ArrayList<Integer> mobList=new ArrayList<Integer>();
		String selectMobIdQry="SELECT mobileid FROM mobiles";
		Integer mId=0;
		try 
		{			
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(selectMobIdQry);
			while(rs.next())
			{
				mId=rs.getInt("mobileId");
				mobList.add(mId);
			}
		} 
		catch (Exception e) 
		{			
			throw new MobileException(e.getMessage());
		}
		finally
		{
			try 
			{
				rs.close();
				st.close();
				con.close();
			} 
			catch (SQLException e)
			{
				throw new MobileException(e.getMessage());
			}
		}
		return mobList;
		
	}

	@Override
	public int getMobileQuanty(int mobId) throws MobileException
	{
		ArrayList<String> mobList=new ArrayList<String>();
		
		String selectMobQuantyQry="SELECT quantity FROM mobiles WHERE mobileId=?";
	
		int mobQuan=0;
		try 
		{			
			con=DBUtil.getCon();
			pst=con.prepareStatement(selectMobQuantyQry);
			pst.setInt(1, mobId);
			rs=pst.executeQuery();
			rs.next();
			
			mobQuan=rs.getInt("quantity");
			//System.out.println("Hii 1"+mobQuan);
			
		} 
		catch (Exception e) 
		{			
			throw new MobileException(e.getMessage());
		}
		finally
		{
			try 
			{
				rs.close();
				pst.close();
				con.close();
			} 
			catch (SQLException e)
			{
				throw new MobileException(e.getMessage());
			}
		}
		return mobQuan;
	}
	
}

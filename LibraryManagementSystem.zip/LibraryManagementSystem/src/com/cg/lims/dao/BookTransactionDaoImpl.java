package com.cg.lims.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

import com.cg.lims.Exception.RegistrationException;
import com.cg.lims.util.DBUtil;

public class BookTransactionDaoImpl implements BookTransactionDao
{
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	static Scanner sc=new Scanner(System.in);

	@Override
	public int retBook(String pid) throws RegistrationException
	{
		String qry="SELECT return_date from Bookstransaction where registration_id="+pid;
		int returnDate = 0;
		try
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(qry);
			System.out.println("shweta pagal");
			rs=pst.executeQuery();
			rs.next();
			returnDate = rs.getInt(pid);

		}
		catch (Exception e)
		{e.printStackTrace();
		throw new RegistrationException(e.getMessage());
		}


		return returnDate;
	

		
	}

}

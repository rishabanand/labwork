package com.cg.lims.dao;

import com.cg.lims.Exception.RegistrationException;

public interface BookTransactionDao 
{
	public int retBook(String pid) throws RegistrationException,Exception;

}

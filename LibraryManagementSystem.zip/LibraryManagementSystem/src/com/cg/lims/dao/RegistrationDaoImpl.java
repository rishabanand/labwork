package com.cg.lims.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;

import com.cg.lims.Exception.RegistrationException;
import com.cg.lims.bean.BookTransaction;
import com.cg.lims.bean.BooksInventory;
import com.cg.lims.bean.BooksRegistration;
import com.cg.lims.ui.TestLibMgmtSystem;
import com.cg.lims.util.*;

public class RegistrationDaoImpl implements RegistrationDao
{
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	static Scanner sc=new Scanner(System.in);
	TestLibMgmtSystem test=new TestLibMgmtSystem();
	BooksInventory bInv=new BooksInventory();

	@Override
	public int addRegistrationDetails(BooksRegistration register) throws RegistrationException, Exception 
	{
		String insertQry="INSERT INTO BooksRegistration VALUES(?,?,?,sysdate)";
		int dataAdded=0;
		try
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(insertQry);
			pst.setString (1, register.getRegistrationId());
			pst.setString(2, register.getBookId());
			pst.setString(3,register.getUserId());
			dataAdded=pst.executeUpdate();
		}
		catch (Exception e)
		{
			throw new RegistrationException(e.getMessage());
		}
		finally
		{
			try
			{
				pst.close();
				con.close();
			}
			catch (Exception e)
			{     

				throw new RegistrationException(e.getMessage());
			}
		}
		return dataAdded;
	}

	@Override
	public String generateRegistId() throws RegistrationException, Exception 
	{
		String qry="SELECT 'R'||to_char(reg_id_seq.NEXTVAL,'FM00') FROM DUAL";
		String generatedVal;
		try
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(qry);
			rs.next();
			generatedVal=rs.getString(1);

		}
		catch (Exception e)
		{e.printStackTrace();
		throw new RegistrationException(e.getMessage());
		}
		finally
		{
			try 
			{
				rs.close();
				st.close();
				con.close();
			} 
			catch (Exception e)
			{e.printStackTrace();
			throw new RegistrationException(e.getMessage());
			}
		}
		return  generatedVal;

	}

	@Override
	public ArrayList<String> getBookId() throws RegistrationException 
	{
		ArrayList<String> booksId=new ArrayList<String>();
		String selectQry=" SELECT book_id FROM BooksInventory ";

		try
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(selectQry);
			while(rs.next())
			{
				String bookId=rs.getString("book_id");
				booksId.add(bookId);
			}
		}
		catch (Exception e)
		{
			throw new RegistrationException(e.getMessage());
		} 
		finally
		{
			try
			{
				rs.close();
				st.close();
				con.close();
			}
			catch (Exception e)
			{
				throw new RegistrationException(e.getMessage());
			}
		}
		return booksId;
	}

	@Override
	public ArrayList<String> getUserId() throws RegistrationException 
	{

		ArrayList<String> userIds=new ArrayList<String>();
		String selectQry=" SELECT user_id FROM Users ";

		try
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(selectQry);
			while(rs.next())
			{
				String userId=rs.getString("user_id");
				userIds.add(userId);
			}
		}
		catch (Exception e)
		{
			throw new RegistrationException(e.getMessage());
		} 
		finally
		{
			try
			{
				rs.close();
				st.close();
				con.close();
			}
			catch (Exception e)
			{
				throw new RegistrationException(e.getMessage());
			}
		}
		return userIds;
	}

	@Override
	public int addBookInventory(BooksInventory bookInv) throws RegistrationException 
	{
		String insertQry="INSERT INTO BooksInventory VALUES(?,?,?,?,?,?)";
		int dataAdded=0;
		String userChoice;


		try
		{

			con=DBUtil.getCon();
			pst=con.prepareStatement(insertQry);

			pst.setString(1, generateBookId());

			pst.setString(2, bookInv.getBookName());
			pst.setString(3,bookInv.getAuthor1());
			pst.setString(4,bookInv.getAuthor2());
			pst.setString(5,bookInv.getPublisher());
			pst.setString(6, bookInv.getYearOfPublication());

			dataAdded=pst.executeUpdate();

		}
		catch (Exception e)
		{
			throw new RegistrationException(e.getMessage());
		}
		finally
		{
			try
			{
				pst.close();
				con.close();
			}
			catch (Exception e)
			{     

				throw new RegistrationException(e.getMessage());
			}
		}
		return dataAdded;
	}

	@Override
	public String generateBookId() throws RegistrationException, Exception 
	{
		String qry="SELECT book_id_seq.NEXTVAL FROM DUAL";
		String generatedVal;
		try
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(qry);
			rs.next();
			generatedVal=rs.getString(1);

		}
		catch (Exception e)
		{e.printStackTrace();
		throw new RegistrationException(e.getMessage());
		}
		finally
		{
			try 
			{
				rs.close();
				st.close();
				con.close();
			} 
			catch (Exception e)
			{e.printStackTrace();
			throw new RegistrationException(e.getMessage());
			}
		}
		return  generatedVal;

	}

	@Override
	public int deleteBook(String bId) throws RegistrationException, Exception 
	{
		String qry="delete from booksinventory where book_id=?";
		int dataDeleted=0;
		try
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(qry);
			pst.setString(1, bId);
			dataDeleted=pst.executeUpdate();

		}
		catch (Exception e)
		{e.printStackTrace();
		throw new RegistrationException(e.getMessage());
		}


		return dataDeleted;
	}

	@Override
	public int issueBook(BookTransaction register) throws RegistrationException, Exception 
	{
		String insertQry="INSERT INTO BooksTransaction VALUES(?,?,sysdate,sysdate+14,0)";
		int dataAdded=0;
		try
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(insertQry);
			pst.setString(1, register.getTransactionId());		
			pst.setString (2, register.getRegistrationId());

			//	pst.setString(3,register.getFine());
			dataAdded=pst.executeUpdate();
		}
		catch (Exception e)
		{
			throw new RegistrationException(e.getMessage());
		}
		finally
		{
			try
			{
				pst.close();
				con.close();
			}
			catch (Exception e)
			{     

				throw new RegistrationException(e.getMessage());
			}
		}
		return dataAdded;
	}


	@Override
	public String generateTransactionId() throws RegistrationException, Exception 
	{
		String qry="SELECT tra_id_seq.NEXTVAL FROM DUAL";
		String generatedVal;
		try
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(qry);
			rs.next();
			generatedVal=rs.getString(1);

		}
		catch (Exception e)
		{e.printStackTrace();
		throw new RegistrationException(e.getMessage());
		}
		finally
		{
			try 
			{
				rs.close();
				st.close();
				con.close();
			} 
			catch (Exception e)
			{e.printStackTrace();
			throw new RegistrationException(e.getMessage());
			}
		}
		return  generatedVal;

	}
	
	@Override
	public ArrayList<String> getRegId() throws RegistrationException 
	{

		ArrayList<String> RegIds=new ArrayList<String>();
		String selectQry=" SELECT registration_id FROM booksregistration";

		try
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(selectQry);
			while(rs.next())
			{
				String RegId=rs.getString("registration_id");
				RegIds.add(RegId);
			}
		}
		catch (Exception e)
		{
			throw new RegistrationException(e.getMessage());
		} 
		finally
		{
			try
			{
				rs.close();
				st.close();
				con.close();
			}
			catch (Exception e)
			{
				throw new RegistrationException(e.getMessage());
			}
		}
		return RegIds;
	}



}

package com.cg.lims.service;

import com.cg.lims.Exception.RegistrationException;
import com.cg.lims.bean.BooksRegistration;

public interface BookTransactionService {
	public int retBook(String pid) throws RegistrationException,Exception;
	
}

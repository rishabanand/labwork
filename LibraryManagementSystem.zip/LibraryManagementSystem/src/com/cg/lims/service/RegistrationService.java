package com.cg.lims.service;

import java.util.ArrayList;

import com.cg.lims.Exception.RegistrationException;
import com.cg.lims.bean.BookTransaction;
import com.cg.lims.bean.BooksInventory;
import com.cg.lims.bean.BooksRegistration;

public interface RegistrationService
{
	public int addRegistrationDetails(BooksRegistration register)throws RegistrationException,Exception;
	public boolean validateIds(String userId,String BookId) throws RegistrationException;
	public String generateRegistId() throws RegistrationException, Exception ;
	public int addBookInventory(BooksInventory bookInv) throws RegistrationException;
	public int deleteBook(String bId) throws RegistrationException,Exception;
	public int issueBook(BookTransaction register) throws RegistrationException, Exception;
	public ArrayList<String> getRegId() throws RegistrationException;
	public boolean validateRegId(String RegId) throws RegistrationException;
	public String generateTransactionId() throws RegistrationException,Exception;
}

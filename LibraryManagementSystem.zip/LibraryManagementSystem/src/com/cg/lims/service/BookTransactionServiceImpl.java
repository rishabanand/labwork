package com.cg.lims.service;

import com.cg.lims.Exception.RegistrationException;
import com.cg.lims.dao.BookTransactionDao;
import com.cg.lims.dao.BookTransactionDaoImpl;

public class BookTransactionServiceImpl implements BookTransactionService
{
	BookTransactionDao traService = new BookTransactionDaoImpl();

	@Override
	public int retBook(String pid) throws RegistrationException, Exception {
		
		return traService.retBook(pid);
	}

}

package com.cg.Service;

import java.sql.SQLException;

import com.cg.dto.Registration;

public interface RegistrationService 
{
	public int addRegistrationDetails(Registration regInfo) throws SQLException;
}

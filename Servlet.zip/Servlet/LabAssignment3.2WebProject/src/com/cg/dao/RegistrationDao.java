package com.cg.dao;

import java.sql.SQLException;

import com.cg.dto.Registration;

public interface RegistrationDao 
{
	public int addRegistrationDetails(Registration regInfo) throws SQLException;
}

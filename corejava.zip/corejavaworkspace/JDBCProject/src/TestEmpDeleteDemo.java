import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;


public class TestEmpDeleteDemo
{
	public static void main(String[] args)
	{
		Connection con=null;
		PreparedStatement pst=null;
		Scanner sc=sc=new Scanner(System.in);
		int dataDeleted=0;
		System.out.println("Enter the no of recors you want to delete");
		int noOfRecords=sc.nextInt();
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");
		} 
		catch (Exception e1) 
		{			
			e1.printStackTrace();
		}
		String deletQry="Delete from emp_142270 where emp_id=?";
		for(int i=0;i<noOfRecords;i++)
		{			
			System.out.println("Enter Employee Id of the record which you want to delete:");
			int empId=sc.nextInt();

			try 
			{
				pst=con.prepareStatement(deletQry);
				pst.setInt(1, empId);
				dataDeleted=pst.executeUpdate();
			} 
			catch (Exception e) 
			{					
				e.printStackTrace();
			}

		}
		System.out.println("Data Deleted ");
	}

}

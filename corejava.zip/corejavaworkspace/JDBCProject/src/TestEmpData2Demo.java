import java.sql.*;
import java.util.*;

public class TestEmpData2Demo 
{
	public static void main(String[] args) 
	{
		Connection con=null;
		PreparedStatement pst=null;
		Scanner sc=sc=new Scanner(System.in);
		int dataAdded=0;
		System.out.println("Enter the no of recors you want to insert");
		int noOfRecords=sc.nextInt();
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");
		} 
		catch (Exception e1) 
		{			
			e1.printStackTrace();
		}
		String insertQry="INSERT INTO emp_142270(emp_id,emp_name,emp_sal) VALUES(?,?,?)";
		for(int i=0;i<noOfRecords;i++)
		{			
			System.out.println("Enter Employee Id :");
			int empId=sc.nextInt();
			System.out.println("Enter Employee Name :");
			String empName=sc.next();
			System.out.println("Enter Employee Salary");
			float empSal=sc.nextFloat();
			
			
			try 
			{
				pst=con.prepareStatement(insertQry);
				pst.setInt(1, empId);
				pst.setString(2, empName);
				pst.setFloat(3, empSal);
				dataAdded=pst.executeUpdate();				
			} 
			catch (Exception e) 
			{					
				e.printStackTrace();
			}
		}
		System.out.println("Data Added "+dataAdded);

	}

}

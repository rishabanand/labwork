import java.io.*;
public class TestFileReadDataDemo 
{
	public static void main(String[] args) 
	{
		File myFile=new File("D:/corejavaworkspace/Day2demos/src/Date.java");
		try 
		{
			FileInputStream fis = new FileInputStream(myFile);
			FileOutputStream fos=new FileOutputStream("MyDate.java");
			int data=fis.read();
			while(data!=-1)
			{
				System.out.print((char)data);
				fos.write(data);
				//fos.flush();
				data=fis.read();
			}
			System.out.println("All Data is written");
		} 
		catch (FileNotFoundException e)
		{			
			e.printStackTrace();
		}
		catch (IOException e)
		{			
			e.printStackTrace();
		}
	}

}

import java.io.*;
import java.util.Properties;

public class TestPropertyFileDemo 
{
	public static void main(String[] args)
	{
		FileReader fr=null;
		Properties props=null;
		try 
		{
			 fr=new FileReader("userInfo.properties");
			 props=new Properties();
			 props.load(fr);//function to read property without comment and loading the value 
			 				//from reader
			 System.out.println("***********all data*********");
			 
			 
				String unm= props.getProperty("username");
				String pwd= props.getProperty("password");
				String location= props.getProperty("location");
				String state= props.getProperty("state");
				System.out.println("User Info :"+unm+" "+pwd+ " "  + "Location"+location+" "+state);
			 
		} 
		catch (IOException e) 
		{			
			e.printStackTrace();
		}
	}
}

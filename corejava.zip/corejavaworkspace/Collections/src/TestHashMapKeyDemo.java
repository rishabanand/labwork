import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import java.util.Map.Entry;


public class TestHashMapKeyDemo 
{
	public static void main(String[] args)
	{
		HashMap<Long,String> mobileDirectory=new HashMap<Long,String>();
		mobileDirectory.put(8888108810L, "Rishab");
		mobileDirectory.put(9860450830L, "Divya");
		mobileDirectory.put(9608450830L, "Shushant");
		mobileDirectory.put(77545453234L, "Priyanka");
		mobileDirectory.put(8888108810L, "Raj");
		
		Collection c = mobileDirectory.keySet();
		Iterator<Long> it=c.iterator();
		while(it.hasNext())
		{
			System.out.println(it.next());
		}
	}

}

import java.util.TreeSet;


public class TestTreeSet
{
	public static void main(String[] args)
	{
		TreeSet<Integer> treeSet=new TreeSet<Integer>();
		Integer i1=new Integer(10);
		Integer i2=new Integer(5);
		Integer i3=new Integer(50);
		Integer i4=new Integer(34);
		Integer i5=new Integer(5);
		
		treeSet.add(i1);
		treeSet.add(i2);
		treeSet.add(i3);
		treeSet.add(i4);
		treeSet.add(i5);
		
		System.out.println(" Without Iterator : "+treeSet);
	
	}
}

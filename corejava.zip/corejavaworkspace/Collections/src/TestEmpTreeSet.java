
import java.util.TreeSet;

public class TestEmpTreeSet 
{
	public static void main(String[] args) 
	{
		TreeSet<Emp> empTreeSet=new TreeSet<Emp>();
		
		Emp e1=new Emp(111,"Rishab",4000.0f);
		Emp e2=new Emp(222,"Divya",5000.0f);
		Emp e3=new Emp(333,"Shushant",6000.0f);
		Emp e4=new Emp(444,"Priyanka",7000.0f);
		Emp e5=new Emp(111,"Rishab",4000.0f);
		
		empTreeSet.add(e1);
		empTreeSet.add(e2);
		empTreeSet.add(e3);
		empTreeSet.add(e4);
		empTreeSet.add(e5);
		
		for(Emp tempE:empTreeSet)
		{
			System.out.println(tempE);
		}
	}
}

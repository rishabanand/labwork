
public class TestDateDemo {

	public static void main(String[] args)
	{
		Date rishabDOJ = null;
		rishabDOJ = new Date();
		rishabDOJ.setDate(13, 12, 2017);
		System.out.println("Rishab DOJ Is :" +rishabDOJ.displayDate());
		
		Date divyaDOJ = new Date();
		divyaDOJ.setDate(25, 10, 2017);
		System.out.println("Divya DOJ Is :" +divyaDOJ.displayDate());
	
		Date unknownPerson = new Date();
		unknownPerson.initDate();
		System.out.println("Unknown person DOJ Is :"+unknownPerson.displayDate());
	}

}

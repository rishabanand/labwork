import java.util.Scanner;
import java.util.regex.*;

public class RegExpTest 
{
	public static void main(String[] args) 
	{
		String inputStr = "Test String";
		String patern = "Test String";
		boolean patternMatched = Pattern.matches(patern, inputStr);
		System.out.println(patternMatched);

		
		String input = "Shop,Mop,Hopping,Chopping";
		Pattern pattern = Pattern.compile("hop");//for searching or we can use test function
		Matcher matcher = pattern.matcher(input);
		//System.out.println(matcher.matches());
		while (matcher.find())//find function for iterating 
		{
			System.out.println(matcher.group() + ": " + matcher.start() + ": "
					+ matcher.end());//group is for printing
		}
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your Mobile Number");
		String mobile=sc.next();
		String mobilePattern="[7-9][0-9]{9}";
		if(Pattern.matches(mobilePattern, mobile))
		{
			System.out.println("Valid Mobile Number");
		}
		else
			System.out.println("Only 10 digits starts with 7 8 9 allowed");
	}
}

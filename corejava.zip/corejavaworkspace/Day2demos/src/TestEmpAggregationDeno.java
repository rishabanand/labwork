import java.util.Scanner;


public class TestEmpAggregationDeno 
{
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the no of Employees");
		int noOfEmp = sc.nextInt();
		Employee employees[] = new Employee[noOfEmp];
		Date dates[] = new Date[noOfEmp];
		int eId = 0,mon = 0,dy = 0,yr = 0;
		float eSal = 0.0f;
		String eName=null;
		
				
		for(int i=0;i<employees.length;i++)
		{
			System.out.println("Enter your Id :");
			eId= sc.nextInt();
			System.out.println("Enter your Name :");
			eName = sc.next();
			System.out.println("Enter Salary :");
			eSal = sc.nextFloat();
			System.out.println("Enter your Day of Joining: ");
			dy = sc.nextInt();
			System.out.println("Enter your Month of Joining :");
			mon = sc.nextInt();
			System.out.println("Enter your Year Of Joining :");
			yr = sc.nextInt();
			
			 dates[i] = new Date(dy,mon,yr);
			employees[i] = new Employee(eId,eName,eSal,dates[i]);
		}
		
		for(int j=0;j<employees.length;j++)
		{
			
			System.out.println(employees[j].dispEmpInfo());
		}
		
	}

}

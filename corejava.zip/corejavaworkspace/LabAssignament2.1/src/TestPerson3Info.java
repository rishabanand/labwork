
public class TestPerson3Info
{
	public static void main(String[] args) 
	{
		Person3 p = new Person3("Divya","Bharti",Gender.Female,"9906201528");
		p.displayPerson3();
	}
}

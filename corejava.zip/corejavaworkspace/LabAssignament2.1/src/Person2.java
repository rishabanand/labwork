
public class Person2 
{
	private String firstName;
	private String lastName;
	private char gender;
	private String phoneNumber;
	
	public Person2()
	{
		
	}
	public Person2(String firstName,String lastName,char gender,String phoneNumber )
	{
		setFirstName(firstName);
		setLastName(lastName);
		setGender(gender);
		setPhoneNumber(phoneNumber);
	}
	public String getFirstName()
	{
		return firstName;
	}
	public String getLastName()
	{
		return lastName;
	}
	public char getGender()
	{
		return gender;
	}
	public String getPhoneNumber()
	{
		return phoneNumber;
	}
	public void setFirstName(String firstName)
	{
		this.firstName = firstName;
	}
	public void setLastName(String lastName)
	{
		this.lastName = lastName;
	}
	public void setGender(char gender)
	{
		this.gender = gender;
	}
	public void setPhoneNumber(String phoneNumber)
	{
		 this.phoneNumber = phoneNumber;
	}
	public void displayPerson2()
	{
		System.out.print("Person Details");
		System.out.println("\n______________");
		System.out.println("Employee Id :"+firstName);
		System.out.println("Employee Name :"+lastName);
		System.out.println("Employee Salary :"+gender);
		System.out.println("Employee Gender :"+phoneNumber);
	}
}

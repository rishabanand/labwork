import java.util.Scanner;


public class StringOperations 
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a String");
		String name =sc.next();
		System.out.println("Enter a choice");
		System.out.println("1.Concatenation\n2.Replacing odd characters with #\n3.Remove Duplicate stsring\n4.Converting the odd characters into Uppercase");
		int  choice = sc.nextInt();
		switch(choice)
		{
		case 1: 	
			String catString = name + name;
			System.out.println("The concatenated String is :"+catString);
			break;
		case 2:
			for(int i=0;i<name.length();i++)
			{
				char currChar =name.charAt(i);
				if(i%2==1)
				{
					name = name.replace(currChar, '#');
				}
			}
			System.out.println(name);
			break;
		case 3:
			char [] ch = name.toCharArray();
			boolean [] t1 =new boolean[256];
			StringBuilder sb = new StringBuilder();
			for(char c :ch)
			{
				if(!t1[c])
				{
					t1[c]=true;
					sb.append(c);
				}
			}
			System.out.println("String without duplicates is  : "+sb.toString());
			break;
		default:
			
			for(int i=0;i<name.length();i++)
			{
				
				char  ch1 =name.charAt(i);
				if(i%2==0)
				{
					System.out.print(Character.toLowerCase(ch1));
				}
				else 
					System.out.print(Character.toUpperCase(ch1));
			}
			
			
			break;
		}
	}
}

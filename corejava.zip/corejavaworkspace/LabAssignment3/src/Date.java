import java.time.*;
import java.util.Scanner;

public class Date
{		
	public void   displayDate(LocalDate date)
	{
		LocalDate today=LocalDate.now();
		//LocalDate myDOJ=LocalDate.of(2013,12,13);
		Period period=Period.between(date,today);
		
		int years=period.getYears();
		int months=period.getMonths();
		int day=period.getDays();
		System.out.println("My Experience In Cg Is :"+years+"Years"+months+"Months"+day+"Days ");
	}
	
	public static void main(String[] args) 
	{
		Date d=new Date();
		//Scanner sc=new Scanner(System.in);
		
		//d.displayDate();
		
		
	}
}

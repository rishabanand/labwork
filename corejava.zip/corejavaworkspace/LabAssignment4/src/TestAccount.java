import java.util.Random;


public class TestAccount
{
	public static void main(String[] args) 
	{
		Person p1 = new Person("Smith",20.0f);
		long acno=new Random().nextLong();
		Account smith = new Account(acno,2000.0,p1);
		
		Person p2 = new Person("Kathy",25.0f);
		Account kathy = new Account(acno,2000.0,p2);
		
		smith.deposit(2000.0);
		kathy.withdrawal(2000.0);
		
		System.out.println("Current balance of Smith :"+smith.getBalance());
		System.out.println("Cureent Balance of Kathy :"+kathy.getBalance());
		
		System.out.println(smith);
		System.out.println(kathy);
		
		
		
	}
}

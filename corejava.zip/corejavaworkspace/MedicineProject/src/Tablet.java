public class Tablet extends Medicine
{
	
	public Tablet()
	{
		super();
	}
	public Tablet(String medName, String compName, String expireDate,
			float price)
	{
		super(medName,compName,expireDate,price);
		
	}
	public String disMedicineInfo()
	{
		return super.disMedicineInfo()+"Store In a cool and Dry Place";
	}
}

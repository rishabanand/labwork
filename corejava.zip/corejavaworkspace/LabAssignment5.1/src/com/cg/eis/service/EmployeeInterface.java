package com.cg.eis.service;

public interface EmployeeInterface 
{
	String calInsuranceScheme(double salary,String designation);
}

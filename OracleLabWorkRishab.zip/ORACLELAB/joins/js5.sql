SELECT s.staff_code,s.staff_name,dp.dept_name,ds.design_name,bt.book_code, b.book_name, b.book_pub_author, 
 5 * (sysdate-to_date(book_expected_return_date,'DD-MON-YY')) as "Fine"     
from staff_master s join department_master dp on dp.dept_code=s.dept_code join  
 designation_master ds on s.design_code=ds.design_code join book_transactions bt on  
 bt.staff_code=s.staff_code join book_master b on bt.book_code=b.book_code;
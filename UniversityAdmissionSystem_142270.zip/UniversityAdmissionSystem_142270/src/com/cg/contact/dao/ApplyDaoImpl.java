package com.cg.contact.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import com.cg.contact.bean.ApplicantBean;
import com.cg.contact.exception.ApplicantException;
import com.cg.contact.util.DBUtil;




public class ApplyDaoImpl implements ApplyDao
{
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	Logger applicantLogger=null;

	public ApplyDaoImpl()
	{
		PropertyConfigurator.configure("resources/log4j.properties");
		applicantLogger=Logger.getLogger("ApplyDaoImpl.class");
	}

	@Override
	public int addApllicantDetails(ApplicantBean applicant)
			throws ApplicantException
	{
		String insertQry="INSERT INTO Candidate_Detail VALUES(?,?,?,?,?,?,?)";
		int dataAdded=0;
		try 
		{
			con=DBUtil.getCon();
			//System.out.println("Hii "+con);
			pst=con.prepareStatement(insertQry);
			pst.setInt(1, generateApplyId());
			pst.setString(2, applicant.getfName());
			pst.setString(3, applicant.getlName());
			pst.setLong(4,applicant.getContactNo());
			pst.setString(5, applicant.getEmail());
			pst.setFloat(6,applicant.getAggregate());
			pst.setString(7,applicant.getStream());
			dataAdded=pst.executeUpdate();
			//System.out.println("Hii3"+applicant.getfName());
			applicantLogger.info("Applicant Information added successfully"+applicant);
		}
		catch (Exception e)
		{
			applicantLogger.error("This is Exception"+e.getMessage());
			throw new ApplicantException(e.getMessage());
			
		} 
		finally
		{
			try 
			{
				pst.close();
				con.close();
			}
			catch (Exception e)
			{
				applicantLogger.error("This is Exception"+e.getMessage());
				throw new ApplicantException(e.getMessage());
			}
		}
		return dataAdded;
	}
	@Override
	public ApplicantBean getApplicantDetails(long applicantId)
			throws ApplicantException 
	{
		String selectQry="SELECT * FROM Candidate_Detail WHERE applyId=?";
		ApplicantBean applicant=null;
		try 
		{			
			con=DBUtil.getCon();
			pst=con.prepareStatement(selectQry);
			pst.setLong(1, applicantId);
			rs=pst.executeQuery();
			System.out.println("Hii");
			while(rs.next())
			{
				applicant=new ApplicantBean(rs.getLong("applyid"),rs.getString("firstName"),rs.getString("lastName"),rs.getString("email"),rs.getLong("contactNo"),rs.getString("stream"),rs.getFloat("aggregate"));
				applicantLogger.info("Candiate_Detail Table Data Reterieved Successfully"+applicant);
				System.out.println("Hii"+applicant);
			}
			
		} 
		catch (Exception e) 
		{	
			applicantLogger.error("This is an Exception related to data reterival"+e.getMessage());
			throw new ApplicantException(e.getMessage());
		}
		finally
		{
			try 
			{
				rs.close();
				pst.close();
				con.close();
			} 
			catch (SQLException e)
			{
				applicantLogger.error("This is an Exception related to data reterieval"+e.getMessage());
				throw new ApplicantException(e.getMessage());
			}
		}
		return applicant;
	}

	@Override
	public int generateApplyId() throws ApplicantException 
	{
		String qry="Select apply_id_seq.NEXTVAL FROM DUAL";
		int generatedVal=0;
		try 
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(qry);
			rs.next();
			generatedVal=rs.getInt(1);
			applicantLogger.info(" Apply Id generated successfully  "+generatedVal);
		}
		catch (Exception e) 
		{
			applicantLogger.error("This is an Exception related to generate Apply Id"+e.getMessage());
			throw new ApplicantException(e.getMessage());
		} 
		finally
		{
			try 
			{
				rs.close();
				st.close();
				con.close();
			} 
			catch (SQLException e)
			{
				applicantLogger.error("This is an Exception related to genearte Purchase Id"+e.getMessage());
				throw new ApplicantException(e.getMessage());
			}
		}
		return generatedVal;


	}

}

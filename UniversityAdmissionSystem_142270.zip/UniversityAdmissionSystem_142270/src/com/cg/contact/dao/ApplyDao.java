package com.cg.contact.dao;

import com.cg.contact.bean.ApplicantBean;
import com.cg.contact.exception.ApplicantException;


public interface ApplyDao
{
public int addApllicantDetails(ApplicantBean applicant)throws ApplicantException;
public ApplicantBean getApplicantDetails(long applicantId) throws ApplicantException;
public int generateApplyId() throws ApplicantException;
}

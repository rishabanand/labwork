package com.cg.contact.service;

import java.util.regex.Pattern;

import com.cg.contact.bean.ApplicantBean;
import com.cg.contact.dao.ApplyDao;
import com.cg.contact.dao.ApplyDaoImpl;
import com.cg.contact.exception.ApplicantException;

public class ApplyServiceImpl implements ApplyService 
{
	ApplyDao applyDao=null;
	public ApplyServiceImpl()
	{
		applyDao=new ApplyDaoImpl();
	}

	@Override
	public int addApllicantDetails(ApplicantBean applicant)
			throws ApplicantException 
	{

		return applyDao.addApllicantDetails(applicant);
	}

	@Override
	public ApplicantBean getApplicantDetails(long applicantId)
			throws ApplicantException 
	{

		return applyDao.getApplicantDetails(applicantId);
	}

	@Override
	public int generateApplyId() throws ApplicantException
	{

		return applyDao.generateApplyId();
	}
	@Override
	public boolean isValidApplicant(ApplicantBean applicant)
			throws ApplicantException
	{
		int flag=0;
		//System.out.println("First Name "+applicant.getfName());
		//System.out.println("LastName "+applicant.getlName());
		if(validateFirstName(applicant.getfName()))
		{
			if(validateLastName(applicant.getlName()))
			{
				if(validateContactNo(applicant.getContactNo()))
				{
					if(validateEmail(applicant.getEmail()))
					{
						if(validateAggregate(applicant.getAggregate()))
						{
							if(validateStream(applicant.getStream()))
							{
								flag=1;
							}
						}
					}
				}
			}
		}
		if(flag==1)
		{
			return true;
		}
		else
		{
			throw new ApplicantException(" May Have some Exception while validating");
		}
	}

	public boolean validateContactNo(long contactNo)
			throws ApplicantException 
	{
		String contactNoPattern="[7-9][0-9]{9}";
		if(Pattern.matches(contactNoPattern, new Long(contactNo).toString()))
		{
			return true;
		}
		else
		{
			throw new ApplicantException("Contact number should be a 10 digit valid mobile number");
		}
	}

	public boolean validateFirstName(String fName)
			throws ApplicantException 
	{
		//System.out.println("first Name"+fName);

		String fNamePattern="[A-Z][a-z]{2,}";
		if(Pattern.matches(fNamePattern,fName))
		{
			return true;
		}

		else  
		{
			throw new ApplicantException("Only Alphabets Allowed and starts with Capital"
					+ " and minimum 2 alphabets are required e.g Rishab");
		}

	}
	public boolean validateLastName(String lName)
			throws ApplicantException 
	{
		String lNamePattern="[A-Z][a-z]+{2,}";
		if(Pattern.matches(lNamePattern, lName))
		{
			return true;
		}

		else  
		{
			throw new ApplicantException("Only Alphabets Allowed and starts with Capital"
					+ " and minimum 2 alphabets are allowed e.g Anand");
		}
	}

	public boolean validateEmail(String email) throws ApplicantException
	{
		String emailPattern="[A-Za-z]+[@][A-Za-z]+[.]com";
		if(Pattern.matches(emailPattern, email))
		{
			return true;
		}
		else
		{
			throw new ApplicantException("Invalid Email Email Id must be like abcd@gmail.com");
		}
	}
	public boolean validateAggregate(float aggregate) throws ApplicantException 
	{
		boolean flag=false;
		String AggregatePattern="[0-9]*{2}[.][0-9]{1,}";
		if(aggregate>0)
		{
		if(Pattern.matches(AggregatePattern, new Float(aggregate).toString()))
		{
			flag=true;
		}
		return flag;
		}
		else
		{
			throw new ApplicantException("Agrregate must be like 40.2 and should be greater than zero");
		}
		
	}
	public boolean validateStream(String stream)
			throws ApplicantException 
	{
		if(stream.equalsIgnoreCase("ComputerScience") || stream.equalsIgnoreCase("InformationTechnology"))
		{
			return true;
		}
		else
		{
			throw new ApplicantException("Stream must be either ComputerScience or InformationTechnology");
		}

	}
}

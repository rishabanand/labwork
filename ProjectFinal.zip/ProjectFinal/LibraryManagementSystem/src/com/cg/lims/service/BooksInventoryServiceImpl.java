package com.cg.lims.service;

import java.time.LocalDate;
import java.util.regex.Pattern;
import com.cg.lims.Exception.BookInventoryException;
import com.cg.lims.bean.BooksInventory;
import com.cg.lims.dao.BooksInventoryDao;
import com.cg.lims.dao.BooksInventoryDaoImpl;

public class BooksInventoryServiceImpl implements BooksInventoryService 
{
	BooksInventoryDao bookInvDao=new BooksInventoryDaoImpl();

	@Override
	public int addBookInventory(BooksInventory bookInv)
			throws BookInventoryException 
	{		
		return bookInvDao.addBookInventory(bookInv);
	}

	@Override
	public String generateBookId() throws BookInventoryException
	{
		return bookInvDao.generateBookId();
	}

	@Override
	public int deleteBook(String bId) throws BookInventoryException 
	{		
		return bookInvDao.deleteBook(bId);
	}

	@Override
	public boolean validateUserInputData(BooksInventory bookInventory ) 
			throws BookInventoryException 
	{	
		
		if(validateBookName(bookInventory)&& 
				validateAuthorName(bookInventory) && validateSecondAuthorName(bookInventory)
				&& validatePublisher(bookInventory)&& validateYearOfPublication(bookInventory))
		{
			return true;
		}
		return false;
	}
	private boolean validateBookName(BooksInventory bookInventory) throws BookInventoryException
	{
		String bookNamePattern="[A-Z][a-z\\s]{2,}";
		if(Pattern.matches(bookNamePattern, bookInventory.getBookName()))
		{
			return true;
		}
		else
		{
			throw new BookInventoryException("Only Chars Allowed and starts with Capital"
					+ " and min 2 and maximum 20 chracters e.g Rishab Anand");
		}
	}
	private boolean validateAuthorName(BooksInventory bookInventory) throws BookInventoryException
	{
		String authorNamePattern="[A-Z][a-z\\s]{2,}";
		if(Pattern.matches(authorNamePattern, bookInventory.getAuthor1()))
		{
			return true;
		}
		else
		{
			throw new BookInventoryException("Only Chars Allowed and starts with Capital"
					+ " and min 2 and maximum 15 chracters e.g Rishab Anand");
		}		
	}
	private boolean validateSecondAuthorName(BooksInventory bookInventory) throws BookInventoryException
	{
		String secondAuthorNamePattern="[A-Z][a-z\\s]{1,}";
		if(Pattern.matches(secondAuthorNamePattern, bookInventory.getAuthor2()))
		{
			return true;
		}
		else
		{
			throw new BookInventoryException("Only Chars Allowed and starts with Capital"
					+ " and min 2 and maximum 15 chracters e.g Rishab Anand");
		}		
	}
	private boolean validatePublisher(BooksInventory bookInventory) throws BookInventoryException
	{
		String bookNamePattern="[A-Z][a-z\\s]{1,}";
		if(Pattern.matches(bookNamePattern, bookInventory.getPublisher()))
		{
			return true;
		}
		else
		{
			throw new BookInventoryException("Only Chars Allowed and starts with Capital"
					+ " and min 2 and maximum 20 chracters e.g Rishab Anand");
		}
	}
	private boolean validateYearOfPublication(BooksInventory bookInventory) throws BookInventoryException
	{
		String yearOfPublication="[0-9]{4}";
		String yearOfPub=bookInventory.getYearOfPublication();
		LocalDate currDate=LocalDate.now();
		int currYear=currDate.getYear();
		int castYearOfPub=Integer.parseInt(yearOfPub);
		if(Pattern.matches(yearOfPublication, yearOfPub)&&castYearOfPub<=currYear)
		{
			return true;
		}
		else
		{
			throw new BookInventoryException("Only four digits are required");
		}
	}

}

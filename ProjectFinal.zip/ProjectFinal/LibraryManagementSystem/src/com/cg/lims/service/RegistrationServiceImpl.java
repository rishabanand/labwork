package com.cg.lims.service;

import java.util.ArrayList;

import com.cg.lims.bean.BooksRegistration;
import com.cg.lims.dao.RegistrationDao;
import com.cg.lims.dao.RegistrationDaoImpl;
import com.cg.lims.exception.RegistrationException;

public class RegistrationServiceImpl implements RegistrationService
{
	RegistrationDao regDao=null;
	public RegistrationServiceImpl()
	{
		regDao=new RegistrationDaoImpl();
	}

	@Override
	public int addRegistrationDetails(BooksRegistration register)
			throws RegistrationException, Exception 
	{		
		return regDao.addRegistrationDetails(register);
	}
		/* To Validate userId and Book Id Received from User for
	               Book Registration by Student*/
	@Override
	public boolean validateIds(String userId,String bookId) throws RegistrationException 
	{		
		//System.out.println("validate UserId value : "+validateUserId(userId));
		//System.out.println("validate BookId value : "+validateBookId(bookId));
		if(validateBookId(bookId) && validateUserId(userId))
		{
			return true;
		}		
		return false;
	}
	
		/*To fetch all userId from users Table */
	private boolean validateUserId(String userId) throws RegistrationException
	{
		ArrayList<String> userIds=regDao.getUserId();
		for(String tempuserIds :userIds)
		{
			if(userId.equals(tempuserIds))
			{
				return true;
			}
		}
		//return false;		
		throw new RegistrationException("Please enter valid userId");
	}
	
		/* To fetch all BookId from Book Inventory Table*/
	
	@Override
	public boolean validateBookId(String bookId) throws RegistrationException
	{
		ArrayList<String> bookIds=regDao.getBookId();
		for(String tempbookIds :bookIds)
		{			
			if(bookId.equals(tempbookIds))
			{	
				return true;
			}
		}
		//return false;
		throw new RegistrationException("Please enter valid BookId");		
	}
	

	@Override
	public String generateRegistId() throws RegistrationException, Exception
	{		
		return regDao.generateRegistId();
	}
}

package com.cg.lims.service;

import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;

import com.cg.lims.Exception.BooksTransactionException;
import com.cg.lims.Exception.RegistrationException;
import com.cg.lims.bean.BookTransaction;

public interface BooksTransactionService
{
	public String generateTransactionId() throws BooksTransactionException;
	public ArrayList<String> getRegId() throws RegistrationException;
	public int issueBook(BookTransaction bookTransaction) throws BooksTransactionException;
	
	public boolean validateRegId(String RegId) throws RegistrationException;
	public boolean validateUserInputDate(LocalDate date)throws RegistrationException;
	public int calculateFine(String transactionId,LocalDate returnDate) throws BooksTransactionException;
	
	
	public Date getReturnDate(String transactionId) throws BooksTransactionException;
	public int updateReturnDateAndFine(String transactionId,int fine,LocalDate returnDate)throws BooksTransactionException;
	public String getBookIdByRegistrationId(String registrationId)throws BooksTransactionException;
}

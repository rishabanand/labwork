package com.cg.lims.dao;


import java.sql.*;
import java.util.ArrayList;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.lims.exception.UserException;
import com.cg.lims.util.DBUtil;

public class UserDaoImpl implements UserDao
{
	Connection con=null;
	Statement st=null;
	ResultSet rs=null;
	PreparedStatement pst=null;
	Logger limsLogger=null;

	public UserDaoImpl()
	{
		PropertyConfigurator.configure("resources/log4j.properties");
		limsLogger=Logger.getLogger("UserDaoImpl.class");
	}
	
	/* To fetch all Usernames from Users Table.*/
	
	@Override
	public ArrayList<String> getUserName() throws UserException,Exception
	{
		ArrayList<String> userNames=new ArrayList<String>();
		try
		{
		con=DBUtil.getCon();
		String selectQry="SELECT user_name FROM users";
		st=con.createStatement();
		rs=st.executeQuery(selectQry);
		while(rs.next())
		{
			String userName=rs.getString("user_name");
			userNames.add(userName);
		}
		limsLogger.log(Level.INFO, "Username: ");

		}
		catch(Exception e)
		{
			limsLogger.error("This is Exception"+e.getMessage());

			throw new UserException("Problem in fetching usernames List "+e.getMessage());
		}
		return userNames;
	}
	 
	/*To fetch all UserPasswords from Users Table.*/

	@Override
	public ArrayList<String> getUserPwd() throws Exception, UserException 
	{
		ArrayList<String> userPwds=new ArrayList<String>();
		try
		{
		con=DBUtil.getCon();
		String selectQry="SELECT password FROM users";
		st=con.createStatement();
		rs=st.executeQuery(selectQry);
		while(rs.next())
		{
			String userPwd=rs.getString("password");
			userPwds.add(userPwd);
		}
		limsLogger.log(Level.INFO, "Password: ");

		}
		catch(Exception e)
		{
			limsLogger.error("This is Exception"+e.getMessage());

			 throw new UserException("Problem in fetching password List "+e.getMessage());
		}
		return userPwds;
	
	}
	
	/* To check whether the User is a Librarian or a Student. */
	
	@Override
	public String getLibrarianValueByUserName(String userName)throws UserException 
	{
		String librarian=null;
		try
		{
		con=DBUtil.getCon();
		String selectQry="SELECT librarian FROM users WHERE user_name=?";
		pst=con.prepareStatement(selectQry);
		pst.setString(1, userName);
		rs=pst.executeQuery();
		rs.next();
		librarian=rs.getString("librarian");
		limsLogger.log(Level.INFO, "Librarian: "+userName);

		}
		catch(Exception e)
		{
			limsLogger.error("This is Exception"+e.getMessage());

			 throw new UserException("Problem in fetching the librarian field value "+e.getMessage());
		}
		return librarian;
	}
	
	/* To get the Username based on the Username to display
		on the Login Screen. */
	
	@Override
	public String getUserNameByUserName(String userName) throws UserException
	{
		String uName=null;
		try
		{
			con=DBUtil.getCon();
			String selectQry="SELECT user_name FROM users WHERE user_name=?";
			pst=con.prepareStatement(selectQry);
			pst.setString(1, userName);
			rs=pst.executeQuery();
			rs.next();
			uName=rs.getString("user_name");
		}
		catch(Exception e)
		{
			throw new UserException("Problem in fetching the user Name "+e.getMessage());
		}
		return uName;
	}
}

package com.cg.lims.junit;

import java.time.LocalDate;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.lims.bean.BookTransaction;
import com.cg.lims.exception.BooksTransactionException;
import com.cg.lims.exception.RegistrationException;
import com.cg.lims.service.BooksTransactionService;
import com.cg.lims.service.BooksTransactionServiceImpl;

public class LimsBookTransaction 
{
	static BookTransaction bookTransaction= null;
	static BooksTransactionService bookTranSer=new BooksTransactionServiceImpl();
	
	@BeforeClass
	public static void beforeClass() throws RegistrationException
	{		
		LocalDate issueDate=LocalDate.of(2018, 02, 24);
		try 
		{
			bookTransaction=new BookTransaction();
			bookTransaction.setTransactionId("BT03");
			bookTransaction.setRegistrationId("R13");
			bookTransaction.setIssueDate(issueDate);
		} 
		catch (Exception e) 
		{
			throw new RegistrationException(e.getMessage());

		}		
	}
	@Test
	public void testBookRegistration() throws BooksTransactionException
	{
		try 
		{
			Assert.assertEquals(1,bookTranSer.issueBook(bookTransaction));
		} 
		catch (Exception e) 
		{
			throw new BooksTransactionException(e.getMessage());
		}
	}
	
}

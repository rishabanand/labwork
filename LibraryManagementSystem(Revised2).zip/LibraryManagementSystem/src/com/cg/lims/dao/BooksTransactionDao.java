package com.cg.lims.dao;

public interface BooksTransactionDao 
{

}

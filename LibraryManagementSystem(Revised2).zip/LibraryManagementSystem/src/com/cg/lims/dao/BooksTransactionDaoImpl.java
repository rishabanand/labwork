package com.cg.lims.dao;

public class BooksTransactionDaoImpl 
{

}

package com.cg.mobilepur.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import com.cg.mobilepur.exception.MobileException;
import com.cg.mobilepur.util.DBUtil;
import com.cg.mobilepur.bean.Mobile;
import com.cg.mobilepur.bean.MobilePurchase;

public class MobileDaoImpl implements MobileDao
{
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	@Override
	public int CustPurDetails(MobilePurchase mobPur) throws MobileException 
	{
		String insertQry="INSERT INTO purchasedetails"
				+ " VALUES(?,?,?,?,?,?)";
		int dataAdded=0;
		try 
		{
			con=DBUtil.getCon();
			//System.out.println("******************"+con);
			pst=con.prepareStatement(insertQry);
			pst.setInt(1, generatePurchaseId());
			pst.setString(2, mobPur.getCustomerName());
			pst.setString(3, mobPur.getMailId());
			pst.setString(4, mobPur.getPhoneno());
			pst.setString(5, mobPur.getPurchaseDate());
			pst.setInt(6,mobPur.getMobileId());
			dataAdded=pst.executeUpdate();
		}
		catch (Exception e)
		{
			throw new MobileException(e.getMessage());			
		} 
		finally
		{
			try 
			{
				pst.close();
			}
			catch (Exception e)
			{
				throw new MobileException(e.getMessage());
			}
		}
		return dataAdded;
	
	}

	@Override
	public int updateMobQuanty(Mobile mob) throws MobileException 
	{
		
		return 0;
	}

	@Override
	public ArrayList<Mobile> getAllMobileDetails() throws MobileException
	{
		
		ArrayList<Mobile> mobList=new ArrayList<Mobile>();
		String selectQry="SELECT * FROM mobiles";
		Mobile m=null;
		try 
		{			
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(selectQry);
			while(rs.next())
			{
				m=new Mobile(rs.getInt("mobileid"),rs.getString("name"),rs.getFloat("price"),rs.getString("quantity"));
				mobList.add(m);
			}
		} 
		catch (Exception e) 
		{			
			throw new MobileException(e.getMessage());
		}
		finally
		{
			try 
			{
				rs.close();
				st.close();
				con.close();
			} 
			catch (SQLException e)
			{
				throw new MobileException(e.getMessage());//wrapping the other exception and then throw
			}
		}
		return mobList;
	}

	@Override
	public int deleteMobDetailById(int mobId) throws MobileException
	{
		return 0;
	}

	@Override
	public ArrayList<Mobile> getMobDetailsByPrice(float price)
			throws MobileException 
	{
		return null;
	}

	@Override
	public int generatePurchaseId() throws MobileException 
	{
		String qry="Select pur_seq.NEXTVAL FROM DUAL";
		int generatedVal=0;
		try 
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(qry);
			rs.next();
			generatedVal=rs.getInt(1);
		}
		catch (Exception e) 
		{
			throw new MobileException(e.getMessage());
		} 
		finally
		{
			try 
			{
				rs.close();
				st.close();
				con.close();
			} 
			catch (SQLException e)
			{
				throw new MobileException(e.getMessage());
			}
		}
		return generatedVal;
	}
	
}

package com.cg.mobilepur.dao;

import java.util.ArrayList;

import com.cg.mobilepur.bean.Mobile;
import com.cg.mobilepur.bean.MobilePurchase;
import com.cg.mobilepur.exception.MobileException;


public interface MobileDao 
{
	public int CustPurDetails(MobilePurchase mobPur) throws MobileException;
	public int updateMobQuanty(Mobile mob) throws MobileException;
	public ArrayList<Mobile> getAllMobileDetails() throws MobileException;
	public int deleteMobDetailById(int mobId) throws MobileException;
	public ArrayList<Mobile> getMobDetailsByPrice(float price) throws MobileException;
	public int generatePurchaseId() throws MobileException;
}

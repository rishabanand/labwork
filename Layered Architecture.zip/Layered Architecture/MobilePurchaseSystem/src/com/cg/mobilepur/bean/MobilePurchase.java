package com.cg.mobilepur.bean;

import java.time.LocalDate;

public class MobilePurchase 
{
	private int purchaseId ;
	private String customerName;
	private String phoneno;
	private String purchaseDate;
	private int mobileId;
	private String mailId;
	
	
	public String getMailId() 
	{
		return mailId;
	}


	public void setMailId(String mailId)
	{
		this.mailId = mailId;
	}


	public MobilePurchase() 
	{
		super();
	}


	public MobilePurchase(int purchaseId, String customerName, String phoneno,
			String purchaseDate, int mobileId) 
	{
		super();
		this.purchaseId = purchaseId;
		this.customerName = customerName;
		this.phoneno = phoneno;
		this.purchaseDate = purchaseDate;
		this.mobileId = mobileId;
	}


	public int getPurchaseId()
	{
		return purchaseId;
	}


	public void setPurchaseId(int purchaseId) 
	{
		this.purchaseId = purchaseId;
	}


	public String getCustomerName()
	{
		return customerName;
	}


	public void setCustomerName(String customerName) 
	{
		this.customerName = customerName;
	}


	public String getPhoneno() 
	{
		return phoneno;
	}


	public void setPhoneno(String phoneno) 
	{
		this.phoneno = phoneno;
	}


	public String getPurchaseDate()
	{
		return purchaseDate;
	}


	public void setPurchaseDate(String purchaseDate) 
	{
		this.purchaseDate = purchaseDate;
	}


	public int getMobileId() 
	{
		return mobileId;
	}


	public void setMobileId(int mobileId) 
	{
		this.mobileId = mobileId;
	}


	@Override
	public String toString() 
	{
		return "MobilePurchase [purchaseId=" + purchaseId + ", customerName="
				+ customerName + ", phoneno=" + phoneno + ", purchaseDate="
				+ purchaseDate + ", mobileId=" + mobileId + "]";
	}
	
	
}

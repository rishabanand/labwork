SELECT s.staff_name "Manager name",count(*) from staff_master s join staff_master m on 
 s.staff_code=m.mgr_code group by  s.staff_name  ;
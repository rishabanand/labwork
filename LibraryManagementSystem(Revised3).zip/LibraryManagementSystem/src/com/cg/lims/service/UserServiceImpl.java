package com.cg.lims.service;

import java.util.ArrayList;

import com.cg.lims.Exception.UserException;
import com.cg.lims.dao.UserDao;
import com.cg.lims.dao.UserDaoImpl;

public class UserServiceImpl implements UserService
{
	UserDao userDao=null;

	public UserServiceImpl()
	{
		userDao=new UserDaoImpl();
	}
	@Override
	public boolean validateUser(String userName,String password) throws Exception, UserException 
	{
		int flag=0;
		if(validateUserName(userName))
		{
			if(validatePassword(password))
			{
				flag=1;
			}
		}
		if(flag==1)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	private boolean validateUserName(String userName) throws UserException, Exception
	{
		ArrayList<String> userNames=userDao.getUserName();
		int flag=0;
		for(String tempbookIds :userNames)
		{
		if(userName.equals(tempbookIds))
		{
			flag=1;
		}
		}
		if(flag==1)
		{
			return true;
		}
		else
		{
			throw new UserException("Invalid UserName. Please check it");
		}
	}
	private boolean validatePassword(String password) throws UserException, Exception
	{
		ArrayList<String> pwds=userDao.getUserPwd();
		int flag=0;
		for(String tempPwds :pwds)
		{
		if(password.equals(tempPwds))
		{
			flag=1;
		}
		}
		if(flag==1)
		{
			return true;
		}
		else
		{
			throw new UserException("Invalid Password. Please check it");
		}
	}
	@Override
	public String getLibrarianValueByUserName(String userName)
			throws UserException
	{		
		return userDao.getLibrarianValueByUserName(userName);
	}
	
	
	
	
}

package com.cg.lims.service;

import com.cg.lims.Exception.BookInventoryException;
import com.cg.lims.bean.BooksInventory;

public interface BooksInventoryService 
{
	public int addBookInventory(BooksInventory bookInv) throws BookInventoryException;
	public String generateBookId() throws BookInventoryException;
	public int deleteBook(String bId) throws BookInventoryException;
}

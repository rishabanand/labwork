
package com.cg.banking.appp;
public class Account {
	
 int accountNo;
  double balance;
 private static int count=1000;
 Personn AccountHolderName;

 public Account()
 {
	
	
 }
public Account(double balance)
{
	count ++;
	accountNo=count;
	this.balance=balance;
	System.out.println("in second");
}





public Personn getAccountHolderName() {
	return AccountHolderName;
}


public void setAccountHolderName(Personn accountHolderName) {
	AccountHolderName = accountHolderName;
}



 
 
 public int getAccountNo() {
	return accountNo;
}
public void setAccountNo(int accountNo) {
	this.accountNo = accountNo;
}


public double getBalance() {
	return balance;
}
public void setBalance(double balance) {
	this.balance = balance;
}

public String toString()
{
return accountNo+" :"+ 	 AccountHolderName + balance;
}






 public void withdraw(double amount)
 {
	 balance=balance-amount;
   System.out.println(+ balance+"debited from your account: "+accountNo);
   System.out.println("updated balance is:" +balance);
	 
 }
  public void deposit(double amount)
   {
	  balance=balance+amount;
	  System.out.println(+ balance+"credited to your account: "+accountNo);
	  System.out.println("updated balance is:" +balance);
	  
	   
   }
  
  

 public void printDetails()
  {
	  System.out.println("accNO :"+accountNo);
	  System.out.println("Account Holder  :"+AccountHolderName);
	  System.out.println("Balance :"+balance);
	  
  }
 

}
package com.cg.banking.appp;

public class AccountMain {
	
	public static void main(String[] args) {
		 Personn p1=new Personn("Smith",45);
		 Personn p2=new Personn("Kathy",34);
		 
		 Account acc1=new Account();
		 acc1.setAccountHolderName(p1);
		 acc1.setBalance(2000);
		 
		 Account acc2=new Account();
		 acc2.setAccountHolderName(p2);
		 acc2.setBalance(3000);
		 
		 acc1.deposit(2000); 
		 acc2.withdraw(2000);
		 
		 Account sav=new SavingAccounts();
		 sav.withdraw(400);
		 Account cur=new CurrentAccount();
		 cur.withdraw(400000);
		 
		 
		 acc1.printDetails();
		 acc2.printDetails();
	

}
}
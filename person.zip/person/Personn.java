package com.cg.banking.appp;

public class Personn extends Account{
	
	String name;
	Float age;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Float getAge() {
		return age;
	}
	public void setAge(Float age) {
		this.age = age;
	}
    public Personn(String name,float age)
    {
    	this.name=name;
    	this.age=age;
    }
    public String toString()
    {
   return name+" :"+ age;	 
    }

}

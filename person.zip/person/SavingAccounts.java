package com.cg.banking.appp;

public class SavingAccounts extends Account{
	final int minimumBalance=500;
	SavingAccounts()
	{
		
	}
	@Override
	
	public void withdraw(double amount){
		System.out.println(amount);
		 if(amount<minimumBalance)
		 {
			 System.out.println("less than minimum balance " );
			
			
		 }
		 
		 super.withdraw(amount); 
		 
		 
		
	}
	
	 

	

	
	
	

}

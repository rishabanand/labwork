package com.cg.banking.appp;

public class CurrentAccount  extends Account{
	final int overDraftLimit =500;

	public int getOverDraftLimit() {
		return overDraftLimit;
	}

	@Override
	public void withdraw(double amount)
	{
		
	}
}

package com.cg.lims.service;

import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.regex.Pattern;

import com.cg.lims.Exception.BooksTransactionException;
import com.cg.lims.Exception.RegistrationException;
import com.cg.lims.bean.BookTransaction;
import com.cg.lims.dao.BooksTransactionDao;
import com.cg.lims.dao.BooksTransactionDaoImpl;

public class BooksTransactionServiceImpl implements BooksTransactionService
{
	BooksTransactionDao bookTransactionDao;
	public BooksTransactionServiceImpl()
	{
		bookTransactionDao=new BooksTransactionDaoImpl();
	}

	@Override
	public String generateTransactionId() throws BooksTransactionException 
	{	
		return bookTransactionDao.generateTransactionId();		
	}

	@Override
	public ArrayList<String> getRegId() throws RegistrationException 
	{
		return bookTransactionDao.getRegId();
	}

	@Override
	public int issueBook(BookTransaction bookTransaction) throws BooksTransactionException 
	{		
		return bookTransactionDao.issueBook(bookTransaction);
	}

	@Override
	public boolean validateRegId(String RegId) throws RegistrationException 
	{

		ArrayList<String> regIds=bookTransactionDao.getRegId();
		for(String tempbookIds :regIds)
		{
			if(RegId.equals(tempbookIds))
			{
				return true;
			}
		}
		
		throw new RegistrationException("Invalid Registration Id. Please check it");
		
	}

	@Override
	public Date getReturnDate(String transactionId)
			throws BooksTransactionException 
	{		
		return bookTransactionDao.getReturnDate(transactionId);
	}

	@Override
	public int updateReturnDateAndFine(String transactionId, int fine,LocalDate returnDate)
			throws BooksTransactionException 
	{		
		return bookTransactionDao.updateReturnDateAndFine(transactionId, fine,returnDate);
	}

	@Override
	public int calculateFine(String registrationId,LocalDate returnDate) throws BooksTransactionException
	{
		//LocalDate currentDate=LocalDate.now();
		LocalDate currentDate=returnDate;
		//int month=returnDate.getMonthValue();
		//int year=returnDate.getYear();
		//int day=returnDate.getDayOfMonth();
		//LocalDate currentDate=LocalDate.of(year,month,day);
		LocalDate returnDateFromTable=null ;
		int fine=0;
		try 
		{
			returnDateFromTable = bookTransactionDao.getReturnDate(registrationId).toLocalDate();
			if(currentDate.isAfter(returnDateFromTable))
			{
				fine=1*(currentDate.getDayOfYear()-returnDateFromTable.getDayOfYear());
			}
			else 
			{
				fine=1*(returnDateFromTable.getDayOfYear()-currentDate.getDayOfYear());
			}
		} 
		catch (Exception e)
		{
			throw new BooksTransactionException(e.getMessage());
		}	
		return fine;
	}

	@Override
	public String getBookIdByRegistrationId(String registrationId)
			throws BooksTransactionException 
	{
		
		return bookTransactionDao.getBookIdByRegistrationId(registrationId);
	}

	@Override
	public boolean validateUserInputDate(LocalDate date) throws RegistrationException 
	{
		if(validateissueDate(date))
		{
			return true;
		}
		
		return false;
	}
	private boolean validateissueDate(LocalDate date) throws RegistrationException
	{
		int month=date.getMonthValue();
		int year=date.getYear();
		int day=date.getDayOfMonth();		
		String stringYearValue=String.valueOf(year);
		String stringDayValue=String.valueOf(day);
		String stringMonthValue=String.valueOf(month);
		String yearPattern="[1-2]{4}";
		String monthPattern="[-][0-9]{2}";
		String dayPattern="[-][0-9]{2}";
		if(Pattern.matches(yearPattern, stringYearValue)&&Pattern.matches(monthPattern, stringMonthValue)
				&&Pattern.matches(dayPattern,stringDayValue) && validateMonthYearDay(day,month,year))
		{
			return true;
		}
		else
		{
			throw new RegistrationException("Only integer values are allowed in the format YYYY-MM-DD"
					+ " and Days=01to31,Months=01-12,Year=1900to2018");
		}		
	}
	private boolean validateMonthYearDay(int day,int month,int year) throws RegistrationException
	{
		if(day>=01 &&day<=31 && month>=01 && month>=12 && year>=1900 && year<=2018)
		{
			return true;
		}
		return false;
	}
}

package com.cg.employee.exception;

public class DepartmentException extends Exception {
	public DepartmentException(String msg) {
		super(msg);
}
}

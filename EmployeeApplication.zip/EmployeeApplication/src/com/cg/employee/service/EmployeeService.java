package com.cg.employee.service;

import com.cg.employee.dto.Employee;
import com.cg.employee.exception.EmployeeException;

public interface EmployeeService {
	public int addEmployee(Employee employee)throws EmployeeException;
	public Employee getEmployeeDetails(int id) throws EmployeeException;
    public long updateEmployee(Employee emp) throws EmployeeException;
    public int deleteEmployee(int id) throws EmployeeException;
}

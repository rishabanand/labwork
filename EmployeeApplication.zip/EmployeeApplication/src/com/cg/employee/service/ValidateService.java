package com.cg.employee.service;

public interface ValidateService {

	public boolean validateFname(String fname);
	public boolean validateLname(String lname);
	public boolean validateGender(String gender);
	public boolean validateMnumber(long number);
	
}

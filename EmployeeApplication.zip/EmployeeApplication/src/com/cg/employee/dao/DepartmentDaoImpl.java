package com.cg.employee.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.employee.dto.Department;
import com.cg.employee.exception.DepartmentException;

import com.cg.employee.util.DatabaseConnection;


public class DepartmentDaoImpl implements DepartmentDao {
	Connection connection ;
	public DepartmentDaoImpl() {
		connection= DatabaseConnection.getConnection();
	
	}
	@Override
	public List<Department> getEmployeeList(int deptno) throws DepartmentException
	 {

			String selQry= "select ename from department where deptno=? ";
			List<Department> employeelist= new ArrayList<Department>();
			try  {
				PreparedStatement ps= connection.prepareStatement(selQry);
				ps.setInt(1, deptno);
				ResultSet rs = ps.executeQuery();
				
				
				while( rs.next()){
					Department dep= new Department();
					dep.setEname(rs.getString(1));
					
					employeelist.add(dep);
				}			
			} catch (SQLException e) {
				throw new DepartmentException(e.getMessage());
			}
					
			return employeelist;
		
	}

}

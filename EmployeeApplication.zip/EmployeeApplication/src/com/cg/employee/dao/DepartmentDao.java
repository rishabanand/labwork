package com.cg.employee.dao;
import java.util.List;

import com.cg.employee.dto.Department;
import com.cg.employee.exception.DepartmentException;

public interface DepartmentDao {
	public List<Department> getEmployeeList(int deptno) throws DepartmentException ;
}

package com.cg.employee.dao;



import com.cg.employee.dto.Employee;
import com.cg.employee.exception.EmployeeException;

public interface EmployeeDao {
	public int addEmployee(Employee employee)throws EmployeeException;
	//public List<Employee> getEmployeeList(int deptno) throws EmployeeException;
	public Employee getEmployeeDetails(int id) throws EmployeeException;
//public String getEmployeeDept(int deptno) throws EmployeeException;
//public Employee getEmpid(int id) throws EmployeeException;
//public List<Employee> getEmployeeDetails(int empid) throws EmployeeException;
public long updateEmployee(Employee emp) throws EmployeeException;
public int deleteEmployee(int id) throws EmployeeException;

}

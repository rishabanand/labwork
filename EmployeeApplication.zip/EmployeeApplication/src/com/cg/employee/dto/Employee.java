package com.cg.employee.dto;
import java.sql.Date;


public class Employee {
	private String fname;
	private String lname;
	private String gender;
	private String email;
	private long  mnumber;
	private Date joinDate;
	private double salary;
	private int empid;

public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
public String getFname() {
	return fname;
}
public void setFname(String fname) {
	this.fname = fname;
}
public String getLname() {
	return lname;
}
public void setLname(String lname) {
	this.lname = lname;
}
public String getGender() {
	return gender;
}
public void setGender(String gender) {
	this.gender = gender;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public long getMnumber() {
	return mnumber;
}
public void setMnumber(long mnumber) {
	this.mnumber = mnumber;
}
public Date getJoinDate() {
	return joinDate;
}
public void setJoinDate(Date joinDate) {
	this.joinDate = joinDate;
}
public double getSalary() {
	return salary;
}
public void setSalary(double salary) {
	this.salary = salary;
}
}

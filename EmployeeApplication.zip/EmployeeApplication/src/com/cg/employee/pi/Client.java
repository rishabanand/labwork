package com.cg.employee.pi;

import java.util.Scanner;

import com.cg.employee.dto.Employee;
import com.cg.employee.exception.EmployeeException;
import com.cg.employee.service.DepartmentService;
import com.cg.employee.service.DepartmentServiceImpl;
import com.cg.employee.service.EmployeeService;
import com.cg.employee.service.EmployeeServiceImpl;





public class Client {
	public static void main(String[] args) {
		
	

	Employee employee= new Employee();
	EmployeeService service= new EmployeeServiceImpl();
	DepartmentService purchase= new DepartmentServiceImpl();
	Scanner sc= new Scanner(System.in);
	int option=0;
	do{
	System.out.println("\n1. Display Employee Details ...");
	System.out.println("2. Display Employee List ...");
	System.out.println("3. Add employee Details  ...");
   System.out.println("4. Update employee number ");
	System.out.println("5. Delete employee details ");
	System.out.println("6. Exit");
	System.out.println("Enter Choice .");
	 option= sc.nextInt();
	 switch(option){
		case 1 :System.out.println("enter employee id");
		int id =sc.nextInt();
		employee.setEmpid(id);
		try
		{Employee empid= service.getEmployeeDetails(id);
		
		System.out.println("employee details : "+ empid );
	} catch (EmployeeException e) {
		
		System.out.println(e.getMessage());
	}	break;
	
		case 2:
			System.out.println("Enter employee first name : ");
		String fname =sc.next();
		System.out.println("Enter employee first name : ");
		String lname =sc.next();
		System.out.println("Enter employee email : ");
		String email =sc.next();
		
		System.out.println("Enter salary : ");
		double salary= sc.nextDouble();
		System.out.println("Enter gender : ");
		String gender= sc.next();
		System.out.println("Enter mobile number : ");
		long mnumber= sc.nextLong();
	    System.out.println("enter joining date");
	   // Date date=sc
		
		
	    employee.setFname(fname);
	    employee.setLname(lname);
	    employee.setEmail(email);
	    
			
		try {
			int empid= service.addEmployee(employee);
			
			System.out.println("Mobile added : "+ empid );
		} catch (EmployeeException e) {
			
			System.out.println(e.getMessage());
		}	
		break;
		case 3:
			}
		
		


	}
package com.cg.employee.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DatabaseConnection {

public static  Connection getConnection(){
	Connection con=null;	
	//connection parameters...
	String url;
	String user;
	String password;
	String driver;
	try {
		InputStream file= new FileInputStream("./resources/jdbc.properties");
		Properties prop= new Properties();
		prop.load(file);
		url= prop.getProperty("url");
		user= prop.getProperty("username");
		password= prop.getProperty("password");
		driver= prop.getProperty("driver");
		Class.forName(driver);
		con=DriverManager.getConnection(url, user, password);
		System.out.println("Database Connected.");
		file.close();
	} catch (ClassNotFoundException e) {
			System.out.println("Driver Class not loaded ..");
	} catch (SQLException e) {
		System.out.println("error while connecting DB ");
	} catch (FileNotFoundException e) {
		System.out.println("file not loaded..");
	} catch (IOException e) {
		System.out.println(e.getMessage());
	}	
	return con;
	
}
public static void main(String[] args) {
	
	getConnection();
}
}

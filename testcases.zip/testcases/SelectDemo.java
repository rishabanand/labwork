package com.cg.jdbc.demo;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class SelectDemo {

	
	public static void main(String[] args) {
	
		Connection con= DatabaseConnection.getConnection();

		String selQuery= "select deptname,deptid from department_master ";
		try {
			Statement stmt= con.createStatement();
			ResultSet rs= stmt.executeQuery(selQuery);
			while(rs.next()){
				int deptid= rs.getInt(2);
				String dname=rs.getString(1);
				System.out.println(deptid+"  "+ dname);
			}
			rs.close();
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
	}
}

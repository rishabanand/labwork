package com.cg.jdbc.demo;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;

public class InsertDemo {
public static void main(String[] args) {
	
	Connection con= DatabaseConnection.getConnection();
	
	String insQuery= "insert into employee_masters "
			+ "( empid, empname, salary ,joindate,deptid) "
			+ " values (?,?,?,?,? )" ;
	
	PreparedStatement ps;
	try {
		ps = con.prepareStatement(insQuery);
		ps.setInt(1, 121);
		ps.setString(2, "Neha");
		ps.setDouble(3, 23000);
		LocalDate jdate= LocalDate.of(2016, 5, 4);
		ps.setDate(4,Date.valueOf(jdate));
		ps.setInt(5, 3);
		int r= ps.executeUpdate();
		System.out.println(r +" rows inserted ...");
	} catch (SQLException e) {
		e.printStackTrace();
	}
}
}

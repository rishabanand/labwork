
function calculateElectricityCharges()
{
	var noOfUnits = frm1.noofunits.value;
	if(noOfUnits>= 0 && noOfUnits<=100)
		var charge = noOfUnits * 2.80;
	else if(noOfUnits>=101 && noOfUnits<=200)
		var charge =  noOfUnits * 3.90;
	else if(noOfUnits>200)
		var charge = noOfUnits * 4.50;
	return charge;
}

function displayElectricityBill()
{
	var consNo = frm1.consumerNo.value; 
	alert(consNo);	// consNo is Consumer Number
	var conName = frm1.consumerName.value; 
	alert(conName);	// conName is Consumer Name
 	var emailAddress = frm1.email.value;
	alert(emailAddress);
	var units = frm1.noofunits.value;
		alert(units);// units is no of units
	var totalCharges = calculateElectricityCharges();
	alert(totalCharges);
	
	alert("Consumer No:"+consNo+"\n Consumer Name:"+conName+"\nEmail Address:"+emailAddress+"\nNumber Of Units:"+units+"\nTotal Charges : "+totalCharges);
	
}

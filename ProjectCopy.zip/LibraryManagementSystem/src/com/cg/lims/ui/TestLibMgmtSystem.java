package com.cg.lims.ui;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;
import com.cg.lims.Exception.BookInventoryException;
import com.cg.lims.Exception.BooksTransactionException;
import com.cg.lims.Exception.RegistrationException;
import com.cg.lims.Exception.UserException;
import com.cg.lims.bean.BookTransaction;
import com.cg.lims.bean.BooksInventory;
import com.cg.lims.bean.BooksRegistration;
import com.cg.lims.service.BooksInventoryService;
import com.cg.lims.service.BooksInventoryServiceImpl;
import com.cg.lims.service.BooksTransactionService;
import com.cg.lims.service.BooksTransactionServiceImpl;
import com.cg.lims.service.RegistrationService;
import com.cg.lims.service.RegistrationServiceImpl;
import com.cg.lims.service.UserService;
import com.cg.lims.service.UserServiceImpl;

public class TestLibMgmtSystem
{
	static Scanner sc=new Scanner(System.in);
	static UserService userService=new UserServiceImpl();
	static RegistrationService regService=new RegistrationServiceImpl();
	static BooksRegistration bookRegi=new BooksRegistration();
	static BooksInventory bookInv = new BooksInventory();
	static BooksInventoryService bookInvService=new BooksInventoryServiceImpl();
	static BooksTransactionService bookTransactionService=new BooksTransactionServiceImpl();
	static BookTransaction bookTransaction=new BookTransaction();
	static int choice=0;
	static int choice1=0;
	static int choice2=0;
	static int choice3=0;
	static int choice4=0;
	static String userName=null;
	public static void main(String[] args) 
	{
		try 
		{
			loginScreen();			
			switch(choice)
			{
			case 1:
				welcomeUserByName(userName);
				studentOptions();
				switch(choice1)
				{
				case 1:addBookRegistrationDetail();
				break;
				case 2: exitFunction();
				default : invalidChoiceStatement();
				//studentOptions();
				}
				break;
			case 2:
				welcomeUserByName(userName);
				librarianOptions();

				switch(choice2)
				{
				case 1: 
					bookInventoryOptions();
					switch(choice3)
					{
					case 1:	
						insertBookInventory();
						break;
					case 2:
						deleteBooksInventory();
						break;

					default: 
						invalidChoiceStatement();
						//bookInventoryOptions();
					}
					break;
				case 2: 
					bookTransactionOptions();

					switch(choice4)
					{
					case 1:
						insertBookTransaction();
						break;
					case 2: 
						returnBook();
						break;
					default: invalidChoiceStatement();
					//bookTransactionOptions();
					}
					break;
				case 3: 
					exitFunction();
					break;				
				default: invalidChoiceStatement();
				//librarianOptions();
				}				
			}
		}
		catch (Exception e) 
		{			
			System.out.println(e.getMessage());
		}

	}
	private static void exitFunction() throws UserException, Exception 
	{
		System.out.println("Thank you for your visit...");
		//loginScreen();		
		System.exit(0);	
	}
	private static void welcomeUserByName(String userName) throws UserException
	{
		System.out.println("Welcome "+userService.getUserNameByUserName(userName));
	}
	private static void invalidChoiceStatement() 
	{
		System.out.println("Invalid Choice.Please enter valid choice....");
	}
	private static void bookTransactionOptions() 
	{
		System.out.println("Hello please choose the following : ");
		System.out.println("1.Issue\n2.Return");
		choice4 = sc.nextInt();		
	}
	private static void bookInventoryOptions() 
	{
		System.out.println("Hello what you want to Perform "); 
		System.out.println("1.Add Book to Inventory\n2.Delete book from Inventory");
		choice3=sc.nextInt();		
	}
	private static void librarianOptions() 
	{
		System.out.println("Choose your Option :");
		System.out.println("1.Books Inventory\n2.Books Transaction\n3.Exit");
		choice2=sc.nextInt();		
	}
	private static void studentOptions()
	{
		System.out.println("Choose your Option :");
		System.out.println("1.Book Registration\n2.Exit");
		choice1=sc.nextInt();		
	}
	private static void loginScreen() throws UserException, Exception
	{
		System.out.println("lOGIN SCREEN");
		System.out.println("Enter Username :");
		userName=sc.next();
		System.out.println("Enter Password :");
		String pwd=sc.next();
		validateUserLogin(userName, pwd);
	}
	private static void returnBook() throws BooksTransactionException, RegistrationException
	{
		String userChoice=null;
		do
		{
			System.out.println("Enter the Registration Id :");
			String registrationId=sc.next(); 
			System.out.println("Enter the return Date in the format YYYY-MM-DD :");
			String returnDate=sc.next();
			DateTimeFormatter myFormat=DateTimeFormatter.ofPattern("yyyy-MM-dd");
			LocalDate returnDate1=LocalDate.parse(returnDate,myFormat);
			if(bookTransactionService.validateRegId(registrationId))
			{
				int fine=bookTransactionService.calculateFine(registrationId,returnDate1);
				int dataUpdated=bookTransactionService.updateReturnDateAndFine(registrationId, fine,returnDate1);
				System.out.println("Hii");
				if(dataUpdated==1)
				{
					System.out.println("Your Fine for Book Id "+bookTransactionService.getBookIdByRegistrationId(registrationId)+" is : "+fine);
					System.out.println("Do You Want to Return one more Book. Say Yes or No");
					userChoice=sc.next();
					System.out.println("Thank you for returning book..");
				}
			}
		}while(userChoice.equalsIgnoreCase("yes"));

	}
	private static void insertBookTransaction() throws RegistrationException, BooksTransactionException 
	{
		String userChoice=null;
		int count=0;
		do
		{
			System.out.println("Please enter Regitration Id");
			String rid = sc.next();
			System.out.println("Enter Issue Date in the format YYY-MM-DD");
			String issueDate=sc.next();
			DateTimeFormatter myFormat=DateTimeFormatter.ofPattern("yyyy-MM-dd");
			LocalDate parsedIssueDate=LocalDate.parse(issueDate,myFormat);
			bookTransaction.setIssueDate(parsedIssueDate);
			if(bookTransactionService.validateRegId(rid))
			{				
				if(count<3)
				{
					int dataAdded=0;
					bookTransaction.setTransactionId(bookTransactionService.generateTransactionId());
					bookTransaction.setRegistrationId(rid);
					dataAdded = bookTransactionService.issueBook(bookTransaction);

					if(dataAdded==1)
					{
						count=count+1;
						System.out.println("Issue Of Book Completed");
						System.out.println("Do You Want to issue one more Book. Say Yes or No");
						userChoice=sc.next();
						System.out.println("Thank you for issuing book...");
					}					
				}
				else
				{
					System.out.println("Account is full with three books");
					break;
				}
			}
		}while(userChoice.equalsIgnoreCase("yes"));
		//librarianOptions();

	}
	private static void deleteBooksInventory() throws BookInventoryException 
	{
		String userChoice=null;
		do
		{
			System.out.println("enter book id to be deleted");
			String bId=sc.next();
			bookInv.setBookId(bId);
			int dataDeleted=0;
			dataDeleted=bookInvService.deleteBook(bId);
			if(dataDeleted==1)
			{
				System.out.println("Book deleted successfully");
				System.out.println("Do You Want to delete one more Book. Say Yes or No");
				userChoice=sc.next();
				System.out.println("Thank you for deleting book...");
			}
		}while(userChoice.equalsIgnoreCase("yes"));
		//librarianOptions();
	}
	private static void insertBookInventory() throws BookInventoryException 
	{
		String userChoice=null;
		do
		{
			int dataAdded=0;
			System.out.println("Enter book Name");
			sc.nextLine();
			String bName=sc.nextLine();
			System.out.println("Enter author name");
			String author1=sc.nextLine();
			System.out.println("Enter Second author name");
			String author2=sc.nextLine();
			System.out.println("Enter the Publisher");
			String publisher=sc.nextLine();
			System.out.println("Enter the year of publication");
			String year=sc.next();
			bookInv.setBookId(bookInvService.generateBookId());
			bookInv.setBookName(bName);
			bookInv.setAuthor1(author1);
			bookInv.setAuthor2(author2);
			bookInv.setPublisher(publisher);
			bookInv.setYearOfPublication(year);
			dataAdded=bookInvService.addBookInventory(bookInv);

			if(dataAdded==1)
			{
				System.out.println("Your request to insert new Book with Book Id "+bookInv.getBookId()+ " completed.");
				System.out.println("Do You Want to Add one more Book. Say Yes or No");
				userChoice=sc.next();
				System.out.println("Thankyou for adding book...");
			}
		}while(userChoice.equalsIgnoreCase("yes"));
		//librarianOptions();
	}
	static void addBookRegistrationDetail() throws RegistrationException, Exception
	{
		int dataAdded=0;
		String userChoice=null;
		do
		{	
			System.out.println("Enter Book Id :");
			String bookId=sc.next();
			System.out.println("Enter User Id :");
			String userId=sc.next();						
			bookRegi.setBookId(bookId);
			bookRegi.setRegistrationId(regService.generateRegistId());
			bookRegi.setUserId(userId);	
			if(regService.validateIds(userId, bookId))
			{
				dataAdded=regService.addRegistrationDetails(bookRegi);

			}
			if(dataAdded==1)
			{
				System.out.println("Your request with registration Id "+bookRegi.getRegistrationId()+" for Book Registration is applied  ");
				System.out.println("Do You Want to Register one more Book. Say Yes or No");
				userChoice=sc.next();
				System.out.println("Thank you for placing a request for a book");
			}
			else
			{
				System.out.println("Problem in adding book details.....");
			}
		}while(userChoice.equalsIgnoreCase("yes"));

	}

	static void validateUserLogin(String userName,String pwd)  throws UserException, Exception
	{	
		if(userService.validateUser(userName, pwd) && 
				userService.getLibrarianValueByUserName(userName).equalsIgnoreCase("n"))
		{	
			choice=1;
		}		
		else if(userService.validateUser(userName, pwd) && 
				userService.getLibrarianValueByUserName(userName).equalsIgnoreCase("y"))
		{
			choice=2;
		}
		else
		{
			System.out.println("Please check your username and password");
			loginScreen();
		}

	}
}



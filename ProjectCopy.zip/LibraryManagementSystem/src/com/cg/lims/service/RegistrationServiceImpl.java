package com.cg.lims.service;

import java.util.ArrayList;

import com.cg.lims.Exception.RegistrationException;
import com.cg.lims.bean.BooksRegistration;
import com.cg.lims.dao.RegistrationDao;
import com.cg.lims.dao.RegistrationDaoImpl;

public class RegistrationServiceImpl implements RegistrationService
{
	RegistrationDao regDao=null;
	public RegistrationServiceImpl()
	{
		regDao=new RegistrationDaoImpl();
	}

	@Override
	public int addRegistrationDetails(BooksRegistration register)
			throws RegistrationException, Exception 
	{		
		return regDao.addRegistrationDetails(register);
	}

	@Override
	public boolean validateIds(String userId,String bookId) throws RegistrationException 
	{	
		System.out.println("Validate book Id value is : "+validateBookId(bookId));
		System.out.println("Validate user Id value is : "+validateUserId(userId));
		if(validateBookId(bookId) && validateUserId(userId))
		{
			return true;
		}		
		throw new RegistrationException("Please enter valid book id and user Id");
	}
	private boolean validateUserId(String userId) throws RegistrationException
	{
		ArrayList<String> userIds=regDao.getUserId();
		for(String tempuserIds :userIds)
		{
			if(userId.equals(tempuserIds))
			{
				return true;
			}
		}
		return false;			
	}
	private boolean validateBookId(String bookId) throws RegistrationException
	{
		ArrayList<String> bookIds=regDao.getBookId();
		for(String tempbookIds :bookIds)
		{			
			if(bookId.equals(tempbookIds))
			{
				return true;
			}
		}
		return false;		
	}

	@Override
	public String generateRegistId() throws RegistrationException, Exception
	{		
		return regDao.generateRegistId();
	}
}

import com.cg.bat.Batch;
import com.cg.stu.Student;


public class TestStudentDemo
{
	public static void main(String[] args) 
	{
		Batch javaBatch=new Batch("JEE_Propel_001","8:30 TO 6:00","Anjulata Tembhare");
		Batch vnvBatch=new Batch("VNV_PT_002","8:30 TO 6:00","Shilpa");
		Batch oracAppBatch=new Batch("OracApp_ABridge_003","8:30 TO 6:00","Sachin Naradekar");
		
		Student student1=new Student(111,"Rishab",90,javaBatch);
		Student student2=new Student(222,"Divya",97,javaBatch);
		Student student3=new Student(333,"Priyanka",85,oracAppBatch);
		Student student4=new Student(444,"Shushant",80,vnvBatch);
		
		System.out.println(student1.disStuInfo());
		System.out.println(student2.disStuInfo());
		System.out.println(student3.disStuInfo());
		System.out.println(student4.disStuInfo());
	}
	

}

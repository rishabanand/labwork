import java.util.Scanner;


public class TestBankAppDemo 
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		int currentBalance=60000;
		System.out.println("Enter the Withdrawal Amount");
		int withdrawalAmt=sc.nextInt();
		if(withdrawalAmt<currentBalance)
		{
			System.out.println("Ok Your have sufficient Balance You can Withdraw");
			
		}
		else
		{
			try 
			{
				throw new LowBalanceException("Please check balance of your Account ");
			} 
			catch (LowBalanceException e) 
			{
				System.out.println("Insufficient Balance in your Account");
			}
		}
	}

}

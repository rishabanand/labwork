import java.io.*;


public class TestEmpFileDemo 
{
	public static void main(String[] args) 
	{
		InputStreamReader isr=new InputStreamReader(System.in);
		BufferedReader br=new BufferedReader(isr);
		try 
		{
			System.out.println("Enter Emp Id");
			int eid=Integer.parseInt(br.readLine());
			
			System.out.println("Enter your Name");
			String enm=br.readLine();
			
			System.out.println("Enter Emp Salary");
			float esl=Float.parseFloat(br.readLine());
			
			System.out.println(eid+" "+enm+" "+esl);
			
			FileWriter fw=new FileWriter("EmpInfo.txt");
			BufferedWriter bw=new BufferedWriter(fw);
			Integer eIdS =new Integer(eid);//called as Boxing converting an primitive type into 
			Float eslS=new Float(esl);
			bw.write(eIdS.toString());
			bw.write(" ");
			bw.write(enm);
			bw.write(" ");
			bw.write(eslS.toString());
			bw.newLine();
			bw.flush();
			System.out.println("Emp Infop written in a file");
		} 
		catch (IOException ie)
		{
			ie.printStackTrace();
		}
		
	}

}


import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.util.Scanner;


public class TestSerializationDemo 
{
	public static void main(String[] args) 
	{
		FileOutputStream fos=null;
		ObjectOutputStream oos=null;
		try 
		{
			fos=new FileOutputStream("EmpData.obj");
			 oos=new ObjectOutputStream(fos);
		} 
		catch (Exception e2) 
		{

			e2.printStackTrace();
		}
		
		for(int i=0;i<3;i++)
		{
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter Emp Id");
			int empId=sc.nextInt();

			System.out.println("Enter Emp Name");
			String empName=sc.next();

			System.out.println("Enter Emp Salary");
			float empSal=sc.nextFloat();
			Emp e1=new Emp(empId,empName,empSal);
			try 
			{
				oos.writeObject(e1);
				System.out.println("Emp Object is written in a file");
			} 
			catch (Exception e) 
			{
				e.printStackTrace();
			}
		}


	}

}

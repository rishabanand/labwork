 import static java.lang.Math.*;
class Parent
{
	public void print()
	{
		System.out.println("Parent :");
	}
	public int add(int ... numbers)
	{
		int sum=0;
		for(int j=0;j<numbers.length;j++)
		{
		sum=sum+numbers[j];
		}
		return sum;
	}
}
class Child extends Parent
{
	@Override
	public void print()
	{
		System.out.println("Child");
	}
}
public class TestJava5FeaturesDemo
{
	public static void main(String[] args)
	{
		System.out.println("PI ="+PI);
		System.out.println("cube of 2 :"+pow(2,3));
		
		
		Parent pp=new Parent();
		System.out.println("The addition of two numbers :"+pp.add(9, 80));
		System.out.println("The addition of two numbers :"+pp.add(9, 80,1));
		
		System.out.println("Enhanced for loop");
		int marks[]=new int [3];
		marks[0]=90;
		marks[1]=10;
		marks[2]=50;
		for(int tempMarks:marks)
		{
			System.out.println(tempMarks);
		}
		String cityList[]={"Pune","Jammu","Yamuna Nagar"};
		for(String city:cityList)
		{
			System.out.println(city);
		}
	}
}

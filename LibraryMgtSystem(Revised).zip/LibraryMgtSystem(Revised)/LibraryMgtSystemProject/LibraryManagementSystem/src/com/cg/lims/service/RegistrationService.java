package com.cg.lims.service;

import com.cg.lims.Exception.RegistrationException;
import com.cg.lims.bean.BooksRegistration;

public interface RegistrationService
{
	public int addRegistrationDetails(BooksRegistration register)throws RegistrationException,Exception;
	public boolean validateIds(String userId,String BookId) throws RegistrationException;
	public String generateRegistId() throws RegistrationException, Exception ;
}
